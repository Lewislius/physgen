"""Paired hidden-state repair: a train-only reference supervises actual delta-H.

    The reference uses the same video, text, sigma and diffusion noise. Structured
    perturbations create recoverable appearance/geometry errors in the student
    input. These perturbations are NOT labelled physical counterexamples.
"""
import torch
import torch.nn.functional as F

from .model import noise_window, rms


@torch.no_grad()
def paired_repair_input(clean, noise, sigma, first, geo, settings):
    from .backbone import fix_first
    reference = fix_first((1-sigma)*clean + sigma*noise, first)
    if float(torch.rand((),device=clean.device)) < settings['clean_probability']:
        return reference, reference, noise-clean, dict(active=False, relative_input_rms=0.)
    b,c,t,h,w = clean.shape
    # Smooth time-varying displacement in latent-pixel coordinates; same source
    # reference remains the target, so no object detector or made-up physics label.
    field = F.interpolate(torch.randn(b,2,3,3,3,device=clean.device),size=(t,h,w),
                          mode='trilinear',align_corners=True)
    field = field/field.square().mean().sqrt().clamp_min(1e-8)
    ys = (torch.arange(h,device=clean.device)+.5)*2/h-1
    xs = (torch.arange(w,device=clean.device)+.5)*2/w-1
    yy,xx = torch.meshgrid(ys,xs,indexing='ij')
    grid = torch.stack((xx,yy),-1)[None,None].expand(b,t,h,w,2).clone()
    pixels = settings['warp_latent_pixels']
    grid += field.permute(0,2,3,4,1)*grid.new_tensor([2*pixels/w,2*pixels/h])
    source = clean.permute(0,2,1,3,4).reshape(b*t,c,h,w).float()
    warped = F.grid_sample(source,grid.reshape(b*t,h,w,2),mode='bilinear',
                           padding_mode='border',align_corners=False)
    warped = warped.reshape(b,t,c,h,w).permute(0,2,1,3,4)
    drift = F.interpolate(torch.randn(b,c,3,2,2,device=clean.device),size=(t,h,w),
                          mode='trilinear',align_corners=True)
    clean_rms = clean.float().square().mean().sqrt().clamp_min(1e-6)
    drift = drift/drift.square().mean().sqrt().clamp_min(1e-8)*clean_rms
    disturbance = .75*(warped-clean)+.25*drift
    # Respect letterbox padding and known first latent slice.
    disturbance *= geo.v_weight.reshape(1,1,1,h,w)
    if first is not None: disturbance[:,:,0] = 0
    disturbance *= clean_rms/disturbance.square().mean().sqrt().clamp_min(1e-8)
    strength = torch.rand((),device=clean.device)*settings['max_relative_strength']
    error = sigma*(1-sigma)*strength*disturbance
    student = fix_first(reference+error,first)
    actual = student-reference
    # Endpoint-restoration target for DIAGNOSTICS ONLY. With sigma-dependent
    # corruption this is not the velocity of the original Gaussian FM path.
    # Training keeps FM on reference; only hidden-state supervision sees student.
    target = noise-clean+actual/sigma.clamp_min(1e-6)
    return reference,student,target,dict(active=True, strength=float(strength),
        relative_input_rms=float(actual.square().mean().sqrt()/clean_rms),
        definition='latent warp + smooth channel drift; not a physical violation label')


def writer_repair_loss(writer, before, state, base, reference_after, sigma, geo, first_known,
                       site, duration, ramp=1.):
    """Writer-only gradients; target is an attainable update from the clean FM forward.

    State and H observations are detached here. STRUCT trains the state, FM trains
    the complete correction, and this loss teaches the writer how to use state.
    """
    before, state, base = before.detach(), state.detach(), base.detach()
    predicted, metrics = writer(before,state,base,sigma,ramp,first_known,site,geo,duration=duration)
    shape = (before.shape[0],len(geo.h_phase),-1,before.shape[-1])
    h, hb = before.reshape(shape).float(), base.reshape(shape).float()
    with torch.no_grad():
        desired = reference_after.detach().reshape(shape).float()-h
        floor,extra = ((.005,.025) if site == 5 else (.010,.040))
        budget = (floor+extra*noise_window(sigma))*ramp
        weight = geo.h_weight.reshape(1,1,-1,1).expand(*shape[:2],h.shape[2],1).clone()
        if first_known: weight[:,0] = 0
        frame_ref = torch.minimum(rms(hb,(-2,-1),weight),rms(h,(-2,-1),weight)).detach()
        token_ref = torch.maximum(torch.minimum(rms(hb),rms(h)),.1*frame_ref)
        # Invert the outer frame bound algebraically. A target t is jointly
        # reachable only if (RMS(t_i)/(2 B R_i))^2 + (RMS_frame(t)/(B R_f))^2 < 1
        # for every token. Independent hard clipping to B would create unreachable
        # targets at the two soft bounds' asymptotes and inflate writer candidates.
        # Radial projection to .95 of this set is idempotent; interior learned
        # corrections are preserved instead of being soft-bounded a second time.
        target = desired*(weight>0)
        token_part = (rms(target)/(2*budget*token_ref).clamp_min(1e-12)).square()
        frame_part = (rms(target,(-2,-1),weight)/(budget*frame_ref).clamp_min(1e-12)).square()
        reach = (token_part+frame_part).amax(-2,keepdim=True).sqrt()
        projection = torch.minimum(torch.ones_like(reach),.95/reach.clamp_min(1e-12))
        target *= projection
        target_rms = rms(target,(-2,-1),weight).mean()
        desired_rms = rms(desired,(-2,-1),weight).mean()
        scale = (budget*frame_ref).clamp_min(1e-6)
    actual = predicted.reshape_as(h).float()-h
    # Dimensionless error relative to this site's permitted frame update. This is
    # a supervised vector target, NOT an L2 penalty shrinking delta-H toward zero.
    error = ((actual-target)/scale).square().mean(-1,keepdim=True)
    loss = (error*weight).sum()/weight.sum().clamp_min(1e-12)
    with torch.no_grad():
        dot = (actual*target*weight).sum()
        denom = ((actual.square()*weight).sum()*(target.square()*weight).sum()).sqrt()
        report = dict(loss=float(loss), target_compression=float(target_rms/desired_rms.clamp_min(1e-12)),
                      target_feasibility_max=float((reach*projection).max()),
                      prediction_target_cosine=float(dot/denom) if float(denom)>0 else None,
                      target_rms=float(target_rms), actual_rms=metrics['actual_rms'])
    return loss,report
