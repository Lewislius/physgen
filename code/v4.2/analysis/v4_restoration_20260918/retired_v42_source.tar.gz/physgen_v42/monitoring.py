"""Detached intervention diagnostics. None of these quantities is a physics score."""
import math

import torch
import torch.nn.functional as F


WRITE_VARIANTS = {"full": (1., 1.), "half": (.5, .5),
                  "writer5_only": (1., 0.), "writer15_only": (0., 1.),
                  "base": (0., 0.)}


def validate_write_scales(scales):
    if len(scales) != 2 or any(not math.isfinite(v) or not 0 <= v <= 1 for v in scales):
        raise ValueError("Writer intervention scales must be two finite values in [0, 1]")
    return tuple(float(v) for v in scales)


@torch.no_grad()
def residual_profile(delta, reference, weight, phase, duration, *, first_known=False,
                     grid_hw=None, maps=False):
    """[B,T,S,C] actual FP32 delta, valid-area weighting, known slice excluded.

    Temporal differences follow fixed grid locations, not tracked objects. Spatial
    and temporal roughness are descriptive and MUST NOT become smoothing losses.
    """
    d, h = delta.detach().float(), reference.detach().float()
    w = weight.float().reshape(1, 1, -1).expand(d.shape[:3]).clone()
    if first_known:
        w[:, 0] = 0
    valid = w > 0
    d2, h2 = d.square().mean(-1), h.square().mean(-1)
    frame_w = w.sum(-1)
    frame_ref = ((h2*w).sum(-1)/frame_w.clamp_min(1e-12)).sqrt()
    frame_delta = ((d2*w).sum(-1)/frame_w.clamp_min(1e-12)).sqrt()
    ref = torch.maximum(h2.sqrt(), .1*frame_ref[..., None]).clamp_min(1e-12)
    ratios = d2.sqrt()/ref
    values = ratios[valid]
    energy = d2*w
    total = energy.sum()
    count = int(valid.sum())
    top = energy[valid].topk(max(1, math.ceil(.01*count))).values.sum() if count else total
    dot = ((d*h).mean(-1)*w).sum()
    denom = (total*(h2*w).sum()).sqrt()
    quantiles = torch.quantile(values, values.new_tensor([.5,.95,.99])) if count else [0.,0.,0.]
    result = dict(actual_rms=float((total/w.sum().clamp_min(1e-12)).sqrt()),
                  token_ratio_p50=float(quantiles[0]), token_ratio_p95=float(quantiles[1]),
                  token_ratio_p99=float(quantiles[2]), token_ratio_max=float(values.max()) if count else 0.,
                  top1pct_energy_share=float(top/total) if float(total)>0 else None,
                  cosine_with_h=float(dot/denom) if float(denom)>0 else None,
                  frame_rms=frame_delta[0].cpu().tolist(),
                  frame_relative_rms=(frame_delta/frame_ref.clamp_min(1e-12))[0].cpu().tolist(),
                  frame_valid=(frame_w[0]>0).cpu().tolist(), phase=phase.float().cpu().tolist())
    dt = phase.diff().float()*float(duration)
    if d.shape[1] > 1:
        pw = torch.minimum(w[:, 1:], w[:, :-1])*(dt>1e-8)[None,:,None]
        temporal = (d[:, 1:]-d[:, :-1]).square().mean(-1)
        pair_den = pw.sum()
        result['temporal_rms_per_second'] = (float(((temporal/dt.clamp_min(1e-8)[None,:,None].square()*pw).sum()/pair_den).sqrt())
                                             if float(pair_den)>0 else None)
        pair_dot = (d[:, 1:]*d[:, :-1]).mean(-1)
        pair_norm = ((d2[:, 1:]*pw).sum()*(d2[:, :-1]*pw).sum()).sqrt()
        result['adjacent_delta_cosine'] = float((pair_dot*pw).sum()/pair_norm) if float(pair_norm)>0 else None
    if grid_hw is not None:
        gh, gw = grid_hw
        dg = d.reshape(*d.shape[:2], gh, gw, d.shape[-1])
        wg = w.reshape(*w.shape[:2], gh, gw)
        spatial_num, spatial_den = d.new_zeros(()), d.new_zeros(())
        for axis in (2, 3):
            if dg.shape[axis] < 2:
                continue
            lhs, rhs = [slice(None)]*5, [slice(None)]*5
            lhs[axis], rhs[axis] = slice(1,None), slice(None,-1)
            pair = torch.minimum(wg[tuple(lhs[:4])], wg[tuple(rhs[:4])])
            spatial_num += ((dg[tuple(lhs)]-dg[tuple(rhs)]).square().mean(-1)*pair).sum()
            spatial_den += pair.sum()
        result['spatial_neighbor_rms'] = float((spatial_num/spatial_den).sqrt()) if float(spatial_den)>0 else None
        if maps:
            size = (min(8,gh), min(8,gw))
            numerator = F.adaptive_avg_pool2d((ratios*w).reshape(-1,1,gh,gw), size)
            denominator = F.adaptive_avg_pool2d(wg.reshape(-1,1,gh,gw), size)
            result['spatial_ratio_map'] = (numerator/denominator.clamp_min(1e-12)).reshape(d.shape[0],d.shape[1],*size)[0].cpu().tolist()
            result['spatial_map_valid'] = (denominator>0).reshape(d.shape[0],d.shape[1],*size)[0].cpu().tolist()
    return result


def register_write_credit(after, before, metrics, gradient_scale=1.):
    """dL_FM/da at a=1 for H_after=H_before+a*actual_delta; no extra backward.

    Caller removes the FM weight / accumulation factor through gradient_scale.
    Positive means locally increasing this write increases conditional FM.
    This derivative is NOT the finite intervention gain or a video-quality label.
    """
    if not torch.is_grad_enabled() or not after.requires_grad:
        return
    delta = (after.detach().float()-before.detach().float())
    def record(gradient):
        with torch.no_grad():
            g = gradient.detach().float()*gradient_scale
            dot = (g*delta).sum()
            norm = (g.square().sum()*delta.square().sum()).sqrt()
            metrics['fm_write_credit'] = dict(dloss_dscale=float(dot),
                grad_delta_cosine=float(dot/norm) if float(norm)>0 else None,
                interpretation='positive: locally increasing this write worsens conditional FM')
        return gradient
    after.register_hook(record)


@torch.no_grad()
def frame_fm_profile(prediction, base, target, first_known):
    start = 1 if first_known else 0
    pred, ref, truth = prediction[:,:,start:].float(), base[:,:,start:].float(), target[:,:,start:].float()
    errors = (pred-truth).square().mean((0,1,3,4))
    baseline = (ref-truth).square().mean((0,1,3,4))
    gain = baseline-errors
    return dict(first_latent_index=start, corrected=errors.cpu().tolist(), base=baseline.cpu().tolist(),
                gain=gain.cpu().tolist(), worst_frame_gain=float(gain.min()),
                improved_frames=int((gain>0).sum()), frames=len(gain))


@torch.no_grad()
def cfg_alignment(delta, positive, negative, first_known):
    start = 1 if first_known else 0
    d = delta[:,:,start:].float()
    direction = (positive-negative)[:,:,start:].float()
    dot = (d*direction).mean()
    de, ce = d.square().mean(), direction.square().mean()
    denom = (de*ce).sqrt()
    return dict(delta_guidance_cosine=float(dot/denom) if float(denom)>0 else None,
                delta_over_guidance_rms=float((de/ce).sqrt()) if float(ce)>0 else None,
                caveat='Alignment with the CFG direction is not prompt adherence or physical correctness')
