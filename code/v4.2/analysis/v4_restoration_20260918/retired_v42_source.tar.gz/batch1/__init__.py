"""Independent batch-one training, reusing the unchanged physgen_v42 modules."""

TRAINING_RECIPE = "fm_joint_bs1_shared_fullnoise_all_losses_v1"
NOISE_RANGE = (.02, .999)
