#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/../tools/runtime_env.sh"
config="${CONFIG:-${V42_ROOT}/batch1/config.yaml}"
v42_python runtime "${V42_ROOT}/batch1/train.py" --config "$config" --check-gpu
args=(--config "$config")
[[ -z "${RESUME:-}" ]] || args+=(--resume "$RESUME")
[[ -z "${RUN_NAME:-}" ]] || args+=(--run-name "$RUN_NAME")
case "${PREPARE:-1}" in
  1) v42_python runtime "${V42_ROOT}/batch1/train.py" "${args[@]}" --prepare-only ;;
  0) ;;
  *) echo 'PREPARE must be 1 (reuse/fill caches) or 0 (already prepared data)' >&2; exit 2 ;;
esac
v42_python runtime "${V42_ROOT}/batch1/train.py" "${args[@]}"
