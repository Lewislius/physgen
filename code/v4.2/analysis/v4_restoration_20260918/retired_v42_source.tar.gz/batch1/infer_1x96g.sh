#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/../tools/runtime_env.sh"
config="${CONFIG:-${V42_ROOT}/batch1/config.yaml}"
output="${OUTPUT:-${V42_ROOT}/inference_outputs/batch1/final_step1200_ema_seed42}"
args=(--config "$config" --output "$output" --suite "${SUITE:-final}")
[[ -z "${CHECKPOINT:-}" ]] || args+=(--checkpoint "$CHECKPOINT")
if [[ "${SUITE:-final}" == single ]]; then
  args+=(--mode "${MODE:-i2v}" --prompt "${PROMPT:?Single inference requires PROMPT}" --duration "${DURATION:-5}")
  if [[ "${MODE:-i2v}" == i2v ]]; then args+=(--image "${IMAGE:?I2V requires IMAGE}"); fi
fi
if [[ "${PORTRAIT:-0}" == 1 ]]; then args+=(--portrait); fi
v42_python runtime "${V42_ROOT}/batch1/infer.py" --phase prepare "${args[@]}"
v42_python teacher "${V42_ROOT}/tools/teacher.py" --phase anchors --output "$output"
v42_python runtime "${V42_ROOT}/batch1/infer.py" --config "$config" --phase sample --output "$output"
v42_python teacher "${V42_ROOT}/tools/teacher.py" --phase generated --output "$output"
v42_python runtime "${V42_ROOT}/inference/report.py" --output "$output"
