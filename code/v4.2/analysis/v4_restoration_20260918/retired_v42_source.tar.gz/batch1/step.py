"""FM, STRUCT and TEMP share one full-range noise draw and one model result."""
import torch

from batch1 import NOISE_RANGE
from physgen_v42.backbone import fix_first
from physgen_v42.geometry import Geometry
from physgen_v42.losses import (auxiliary_objective, fm_loss, generation_objective,
                               local_pair_specs, struct_loss, struct_noise_weight, temporal_loss)
from physgen_v42.optim import ramp
from physgen_v42.runtime import autocast


def train_step(model, decoder, sample, exposure, step, mixer, negative, loss_weights=None):
    if (not exposure["temporal"] or exposure["repair"] or
            not 1 <= step <= 1200 or negative is None):
        raise ValueError("Batch1 requires all losses at the same sampled noise; repair is disabled")
    weights = loss_weights or dict(fm=1., struct=.1, temp=.05)
    a, device = model.adapter, sample["latent"].device
    geo = Geometry.build(sample["record"]["geometry"], device)
    first, xgt, text = sample["first"], sample["latent"], sample["text"]
    duration, mode = sample["record"]["duration"], exposure["mode"]
    sigma = torch.empty((), device=device).uniform_(*NOISE_RANGE)
    noise = torch.randn_like(xgt)
    x = fix_first((1 - sigma) * xgt + sigma * noise, first)
    target = noise - xgt
    with autocast(device):
        p0 = a.initialize(text, geo, mode, sample["anchor"])
        # Reuse the same x/sigma/state for conditional FM and the original CFG TEMP.
        # ProcessWan computes conditional/unconditional predictions internally.
        result = model(x, first, text, sigma, duration, geo, p0, negative, ramp(step))
        loss_fm = fm_loss(result["cond"], target, first is not None)
        xhat = fix_first(x - sigma * result["guided"], first)
        specs = local_pair_specs(sample["record"], exposure["exposure"])
        with torch.no_grad():
            reference = decoder.views(fix_first(xgt, first), specs)
        decoded = decoder.views(xhat, specs)
        loss_temp = temporal_loss(decoded, reference, sample["record"]["geometry"], specs)
        generation = generation_objective(loss_fm, loss_temp, accumulation=1,
                                          fm_weight=weights["fm"], temp_weight=weights["temp"])
    generation.backward()
    # Keep the original detached STRUCT route and its gradient budget; use this
    # same prediction's observations and exactly the same sigma, with no resample.
    with autocast(device):
        p15_aux = a.auxiliary(result["p0"], result["observations"], text, sigma, duration, geo)
        loss_struct = struct_loss(p15_aux, sample["target"], a.s_z, geo.p_weight, sample["instances"])
        weighted_struct = auxiliary_objective(loss_struct, sigma, accumulation=1, weight=weights["struct"])
    mixer.accumulate_aux(weighted_struct)
    return dict(fm=float(loss_fm.detach()), struct=float(loss_struct.detach()), temp=float(loss_temp.detach()),
                weighted_fm=weights["fm"] * float(loss_fm.detach()), weighted_struct=float(weighted_struct.detach()),
                weighted_temp=weights["temp"] * float(loss_temp.detach()), sigma=float(sigma), sigma_a=float(sigma),
                fm_active=True, struct_active=True, temporal_active=True, shared_noise=True,
                struct_noise_weight=float(struct_noise_weight(sigma)), repair=False, fm_repair=False,
                temporal_sigma=float(sigma), temporal_sigma_a=float(sigma),
                interventions=result["metrics"], out_of_range=float(decoded["out_of_range"]))
