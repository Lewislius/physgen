"""Independent BS=1/accumulation=1 training: FM, STRUCT and TEMP on every source."""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import sys
import time
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch

from batch1 import TRAINING_RECIPE
from batch1.checkpoint import SAVE_STEPS, load_training, save_checkpoint
from batch1.config import DEFAULT_CONFIG, code_fingerprint, configuration, prepare_data
from batch1.data import ExposurePlan
from batch1.step import train_step
from physgen_v42.backbone import ProcessWan, load_wan
from physgen_v42.cache import ready_valid
from physgen_v42.data import Dataset
from physgen_v42.encoders import Decoder, load_vae
from physgen_v42.model import Adapter
from physgen_v42.optim import EMA, GradientMixer, optimizer_for, ramp, restore_rng, set_schedule
from physgen_v42.runtime import (digest, job_lock, lock_assets, log, output_path, read_json,
                                require_environment, require_single_gpu, save_json, seed_all, sha256)
from physgen_v42.training_log import TrainingProgress, loss_breakdown
from train.train import health_check, norm_group


def train(cfg, args, device):
    dataset, validation = Dataset(cfg, "train"), Dataset(cfg, "validation", require_complete=False)
    root = Path(cfg["paths"]["cache"])
    assets, ready = lock_assets(cfg), read_json(root / "ready.json")
    if ready["statistics_sha256"] != sha256(root / "stats.pt") or assets != dataset.manifest["assets"]:
        raise ValueError("Shared cache calibration/assets do not match finalized data")
    stats = torch.load(root / "stats.pt", map_location="cpu", weights_only=True)
    if stats["manifest_hash"] != digest(dataset.manifest) or stats["train_count"] != len(dataset):
        raise ValueError("Statistics are not calibrated on the current training sources")
    seed_all(cfg["train"]["seed"])
    adapter = Adapter(cfg, stats).float().to(device)
    count = sum(p.numel() for p in adapter.parameters())
    if count >= 100_000_000:
        raise ValueError(f"Trainable parameter budget exceeded: {count}")
    optimizer = optimizer_for(adapter, cfg)
    plan = ExposurePlan(dataset.records, cfg["train"]["seed"])
    identity = dict(manifest=digest(dataset.manifest), statistics=ready["statistics_sha256"],
                    assets=digest(assets), code=digest(code_fingerprint()))
    start, ema, resume_rng = 0, EMA(adapter, cfg["train"]["ema_decay"]), None
    checkpoint_root = Path(cfg["paths"]["checkpoints"]).resolve()
    if args.resume:
        resume = Path(args.resume).expanduser().resolve()
        if checkpoint_root not in resume.parents:
            raise ValueError("Batch1 resume must use its separate checkpoints/batch1 directory")
        start, ema, resume_rng = load_training(resume, adapter, optimizer, plan, cfg, identity)
        run_dir = output_path(resume.parent)
        run_name = run_dir.name
    else:
        run_name = args.run_name or "batch1_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid.uuid4().hex[:6]
        if Path(run_name).name != run_name or run_name in (".", ".."):
            raise ValueError("run-name must be a simple directory name")
        run_dir = output_path(checkpoint_root / run_name)
        run_dir.mkdir(parents=True, exist_ok=False)
    log_dir = Path(cfg["paths"]["logs"]) / run_name
    save_json(dict(config=cfg, identity=identity, training_recipe=TRAINING_RECIPE,
                   parameters=count, groups={k: sum(p.numel() for p in v.parameters())
                                             for k, v in adapter.groups().items()},
                   gpu=torch.cuda.get_device_name(device), batch_size=1, accumulation=1,
                   loss_reporting=dict(
                       fm="L_fm; conditional prediction at sigma U(.02,.999) on every step",
                       struct=f"{cfg['loss']['struct']} * aux_alpha * q(sigma_fm) * L_struct; detached core paths only",
                       temp="0.05 * L_temp; same video/noise/sigma U(.02,.999) as FM/STRUCT, CFG at every step",
                       total="FM + effective STRUCT + TEMP; no division by eight; alpha fixed before global clipping")),
              log_dir / "run.json")
    log(log_dir / "events.jsonl", console=False, event="start", run=str(run_dir), step=start,
        parameters=count, identity=identity, batch_size=1)
    model = ProcessWan(load_wan(cfg["paths"]["wan_checkpoint"], device), adapter)
    decoder = Decoder(load_vae(cfg["paths"], device), save_on_cpu=cfg["train"]["decoder_save_on_cpu"])
    negative = torch.load(root / "negative.pt", map_location=device, weights_only=True)[None]
    if resume_rng is not None:
        restore_rng(resume_rng)
    with job_lock(run_dir / ".training.lock"), TrainingProgress(1200) as progress:
        for step in range(start + 1, 1201):
            started = time.perf_counter()
            set_schedule(adapter, optimizer, cfg, step)
            optimizer.zero_grad(set_to_none=True)
            mixer = GradientMixer(adapter.core_parameters(), adapter.parameters())
            exposure, = plan.batch(step)
            progress.start_step(step, 1)
            sample = dataset.load(exposure["index"], exposure["mode"], device)
            values = train_step(model, decoder, sample, exposure, step, mixer, negative, cfg["loss"])
            log(log_dir / "micro.jsonl", console=False, event="micro", step=step, micro=0,
                id=sample["record"]["id"], category=sample["record"]["category"],
                mode=exposure["mode"], duration=sample["record"]["duration"],
                exposure=exposure["exposure"], **values)
            del sample
            combined = mixer.combine(max_share=cfg["train"]["aux_ratio"])
            before_update = {name: [p.detach().clone() for p in group.parameters()]
                             for name, group in adapter.groups().items()}
            norms = {name: norm_group(module) for name, module in adapter.groups().items()}
            total_norm = torch.nn.utils.clip_grad_norm_(adapter.parameters(), cfg["train"]["grad_clip"], error_if_nonfinite=True)
            optimizer.step()
            ema.update(adapter)
            updates = {name: float(torch.stack([(p.detach() - old).square().sum() for p, old in
                       zip(group.parameters(), before_update[name])]).sum().sqrt())
                       for name, group in adapter.groups().items()}
            del before_update, mixer
            torch.cuda.synchronize(device)
            update = dict(event="update", step=step, phase="joint",
                          seconds=time.perf_counter() - started,
                          **loss_breakdown([values], cfg["loss"], combined["aux_alpha"]),
                          global_grad_norm=float(total_norm), grad_groups=norms, parameter_update_norms=updates,
                          lr={g["name"]: g["lr"] for g in optimizer.param_groups}, ramp=ramp(step),
                          batch_size=1, accumulation=1, temporal_active=1, repair_active=int(exposure["repair"]),
                          fm_repair_active=0, shared_noise=True, sigma_fm=values["sigma"],
                          sigma_struct=values["sigma"], sigma_temp=values["temporal_sigma"],
                          **combined, peak_allocated_gib=torch.cuda.max_memory_allocated(device) / 2**30,
                          peak_reserved_gib=torch.cuda.max_memory_reserved(device) / 2**30)
            log(log_dir / "updates.jsonl", console=False, **update)
            progress.finish_step(update)
            if step % 200 == 0:
                loss = health_check(model, validation, step, log_dir / "health.jsonl", console=False)
                log(log_dir / "updates.jsonl", console=False, event="validation", step=step, validation_loss=loss)
            if step in SAVE_STEPS:
                path = save_checkpoint(run_dir, step, adapter, optimizer, ema, plan, cfg, identity)
                log(log_dir / "events.jsonl", console=False, event="checkpoint", path=str(path), step=step)
        save_json(dict(checkpoint=str(run_dir / "step1200"), step=1200), checkpoint_root / "latest_final.json")
        save_json(plan.state_dict(), log_dir / "exposure_coverage.json")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--resume")
    parser.add_argument("--run-name")
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--check-config", action="store_true", help="Validate config/cache reuse without CUDA or training")
    action.add_argument("--check-gpu", action="store_true")
    action.add_argument("--prepare-only", action="store_true", help="Reuse existing complete caches; fill missing components")
    args = parser.parse_args()
    require_environment("runtime")
    cfg = configuration(args.config)
    if args.check_config:
        log(event="batch1_config_valid", config=cfg, cache_ready=ready_valid(cfg))
        return
    if args.prepare_only:
        prepare_data(cfg, resume=bool(args.resume))
        return
    device = require_single_gpu()
    if args.check_gpu:
        log(event="gpu_ready", python=sys.executable, torch_version=torch.__version__,
            torch_cuda=torch.version.cuda, gpu=torch.cuda.get_device_name(device), batch_size=1)
        return
    train(cfg, args, device)


if __name__ == "__main__":
    main()
