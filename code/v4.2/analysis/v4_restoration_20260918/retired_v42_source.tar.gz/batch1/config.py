"""Resolve a batch-one overlay without relaxing the original batch-eight contract."""
from copy import deepcopy
import json
from pathlib import Path

import yaml

from batch1 import NOISE_RANGE, TRAINING_RECIPE
from physgen_v42.runtime import (ROOT, code_fingerprint as original_fingerprint, digest,
                                read_config as original_config, sha256)

DEFAULT_CONFIG = ROOT / "batch1/config.yaml"
EXPECTED = dict(
    purpose="batch1_all_losses",
    train=dict(accumulation=1, steps=1200, save_every=100),
    noise=dict(shared=list(NOISE_RANGE)),
    mode_cycle=["i2v", "i2v", "i2v", "t2v"],
)


def configuration(path=DEFAULT_CONFIG):
    """Accept the overlay YAML or the resolved config.json saved in our checkpoints."""
    path = Path(path).expanduser().resolve()
    source = path.read_text().replace("${V42_ROOT}", str(ROOT))
    # JSON scientific notation such as 5e-05 is parsed as a string by YAML 1.1.
    raw = json.loads(source) if path.suffix == ".json" else yaml.safe_load(source)
    if not isinstance(raw, dict):
        raise ValueError("Expected a batch1 configuration mapping")
    resolved = "model_version" in raw
    settings = deepcopy(raw.get("batch1", {}) if resolved else raw)
    if set(settings) != set(EXPECTED) | {"base_config"}:
        raise ValueError("Expected the independent batch1 config, not the batch8 config")
    for key, value in EXPECTED.items():
        if settings[key] != value:
            raise ValueError(f"Batch1 requires {key}={value}")
    base = Path(settings["base_config"]).expanduser()
    settings["base_config"] = str((path.parent / base).resolve() if not base.is_absolute() else base.resolve())
    cfg = original_config(settings["base_config"])
    cfg["batch1"] = settings
    cfg["train"].update(settings["train"], recipe=TRAINING_RECIPE)
    # Stay inside already-excluded output directories, with separate latest pointers.
    for key, suffix in dict(checkpoints="checkpoints/batch1", logs="train/train_log/batch1",
                            outputs="inference_outputs/batch1").items():
        cfg["paths"][key] = str(ROOT / suffix)
    if resolved and digest(raw) != digest(cfg):
        raise ValueError("Saved batch1 configuration differs from the current base/recipe")
    return cfg


def code_fingerprint():
    files = original_fingerprint()
    files.update({str(p.relative_to(ROOT)): sha256(p)
                  for p in sorted((ROOT / "batch1").glob("*.py"))})
    return files


def prepare_data(cfg, resume=False):
    from physgen_v42.cache import ready_valid
    from physgen_v42.runtime import log
    from tools.bootstrap import ensure_data
    if ready_valid(cfg):
        log(event="batch1_cache_reused", cache=cfg["paths"]["cache"])
        return
    # Existing preparation programs require the original (batch8) configuration.
    # Its data/assets are identical; only the new training/output settings differ.
    base_path = cfg["batch1"]["base_config"]
    ensure_data(original_config(base_path), base_path, resume=resume)
    if not ready_valid(cfg):
        raise RuntimeError("Shared cache is still incomplete after preparation")
