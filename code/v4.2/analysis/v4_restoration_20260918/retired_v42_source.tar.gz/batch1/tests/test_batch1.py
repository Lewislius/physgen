"""CPU numerical checks for loss routing, source coverage, and exact BS1 resume."""
from contextlib import nullcontext
from copy import deepcopy
from pathlib import Path
import random
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import numpy as np
import torch

from batch1 import TRAINING_RECIPE
from batch1 import step as steps
from batch1.checkpoint import SAVE_STEPS, load_training, save_checkpoint
from batch1.config import code_fingerprint, configuration, prepare_data
from batch1.data import ExposurePlan
from batch1.infer import implementation
from physgen_v42 import optim as original_optim
from physgen_v42.optim import EMA, GradientMixer, optimizer_for, restore_rng, set_schedule
from physgen_v42.runtime import ROOT, code_fingerprint as original_fingerprint, digest, read_config, read_json, save_json
from physgen_v42.training_log import loss_breakdown


class ToyAdapter(torch.nn.Module):
    def __init__(self):
        super().__init__()
        for i, name in enumerate(("core5", "core15", "text_init", "writer5", "writer15"), 1):
            layer = torch.nn.Linear(1, 1, bias=False)
            layer.weight.data.fill_(i / 5)
            setattr(self, name, layer)
        self.register_buffer("s_z", torch.tensor(1.))

    def groups(self):
        return {name: getattr(self, name) for name in ("core5", "core15", "text_init", "writer5", "writer15")}

    def core_parameters(self):
        yield from self.core5.parameters()
        yield from self.core15.parameters()

    def initialize(self, text, geo, mode, anchor):
        return self.text_init(text) if mode == "t2v" else anchor.detach()

    def auxiliary(self, p0, observations, text, sigma, duration, geo):
        return self.core15(self.core5(p0.detach() + observations[0].detach())).reshape(1, 1, 1, 1)


class ToyModel:
    def __init__(self):
        self.adapter, self.calls = ToyAdapter(), []

    def __call__(self, x, first, text, sigma, duration, geo, p0, negative=None, ramp=1.):
        a = self.adapter
        change = a.writer15(a.core15(a.writer5(a.core5(p0)))).reshape(1, 1, 1, 1, 1)
        cond = (.2 + ramp * change) * x
        guided = None if negative is None else cond + .25 * x
        self.calls.append(dict(x=x.detach().clone(), sigma=sigma.detach().clone(),
                               cond=cond.detach().clone(), guided=None if guided is None else guided.detach().clone(),
                               grad_enabled=torch.is_grad_enabled()))
        return dict(cond=cond, guided=guided, p0=p0.detach(),
                    observations=(x.detach().mean().reshape(1, 1),), metrics={})


class ToyDecoder:
    def __init__(self):
        self.inputs = []

    def views(self, latent, specs):
        self.inputs.append(latent.detach().clone())
        return dict(global_rgb=latent[0].permute(1, 0, 2, 3), out_of_range=latent.new_zeros(()))


def run_step(step, mode="t2v", weights=None, sigma=.8):
    torch.manual_seed(51)
    model, decoder = ToyModel(), ToyDecoder()
    latent = torch.randn(1, 3, 5, 2, 2)
    sample = dict(latent=latent, first=latent[:, :, :1].clone() if mode == "i2v" else None,
                  text=torch.ones(1, 1), anchor=torch.ones(1, 1) if mode == "i2v" else None,
                  target=torch.zeros(1, 1, 1, 1), instances=None,
                  record=dict(duration=.2, objects_reliable=False,
                              geometry=dict(h=2, w=2, rh=2, rw=2, top=0, left=0, frames=5)))
    mixer = GradientMixer(model.adapter.core_parameters(), model.adapter.parameters())
    exposure = dict(mode=mode, temporal=True, repair=False, exposure=0)
    geo, ranges = SimpleNamespace(p_weight=torch.ones(1)), []

    def draw(tensor, low, high):
        ranges.append((low, high))
        return tensor.fill_(sigma)

    with patch.object(steps.Geometry, "build", return_value=geo), \
            patch.object(steps, "autocast", side_effect=lambda device: nullcontext()), \
            patch.object(torch.Tensor, "uniform_", new=draw), \
            patch.object(torch, "randn_like", wraps=torch.randn_like) as noise:
        values = steps.train_step(model, decoder, sample, exposure, step, mixer,
                                  torch.zeros(1, 1), loss_weights=weights)
        assert noise.call_count == 1, "All losses must reuse exactly one noise tensor"
    return model, decoder, sample, mixer, values, ranges


class BatchOneTests(unittest.TestCase):
    def test_config_reuses_data_and_preserves_original_fingerprint(self):
        old = read_config(ROOT / "configs/stability.yaml")
        cfg = configuration()
        self.assertEqual(old["train"]["accumulation"], 8)
        self.assertEqual(old["train"]["save_every"], 100)
        self.assertEqual(cfg["train"]["accumulation"], 1)
        self.assertEqual((cfg["train"]["steps"], cfg["train"]["save_every"]), (1200, 100))
        self.assertEqual(cfg["data"], old["data"])
        for name in ("cache", "annotations", "asset_lock", "wan_checkpoint", "teacher_checkpoint"):
            self.assertEqual(cfg["paths"][name], old["paths"][name])
        for name in ("logs", "checkpoints", "outputs"):
            self.assertNotEqual(cfg["paths"][name], old["paths"][name])
        original = original_fingerprint()
        extended = code_fingerprint()
        self.assertTrue(all(not name.startswith("batch1/") for name in original))
        self.assertEqual({k: extended[k] for k in original}, original)
        self.assertIn("batch1/step.py", extended)
        with tempfile.TemporaryDirectory(dir=ROOT / "tmp") as tmp:
            path = Path(tmp) / "config.json"
            save_json(cfg, path)
            self.assertEqual(configuration(path), cfg)
        with self.assertRaisesRegex(ValueError, "batch1 config"):
            configuration(ROOT / "configs/stability.yaml")

    def test_complete_cache_skips_preparation(self):
        with patch("physgen_v42.cache.ready_valid", return_value=True), \
                patch("tools.bootstrap.ensure_data") as prepare, patch("physgen_v42.runtime.log"):
            prepare_data(configuration())
            prepare.assert_not_called()

    def test_all_1200_updates_use_one_source_and_three_losses(self):
        plan = ExposurePlan([dict(category="unlabeled") for _ in range(2279)], 42)
        indices, modes = [], []
        for step in range(1, 1201):
            exposure, = plan.batch(step)
            self.assertTrue(exposure["temporal"])
            self.assertFalse(exposure["repair"])
            self.assertEqual(exposure["exposure"], 0)
            indices.append(exposure["index"])
            modes.append(exposure["mode"])
            plan.validate_state(plan.state_dict(), step)
        self.assertEqual(len(set(indices)), 1200)
        self.assertEqual(modes.count("i2v"), 900)
        self.assertEqual(modes.count("t2v"), 300)
        self.assertEqual(sum(c["temp"] for c in plan.counts), 1200)
        with self.assertRaisesRegex(ValueError, "sequential"):
            plan.batch(1201)

    def test_all_losses_have_correct_weights_and_shared_noise(self):
        for step in (1, 800, 801, 1200):
            for mode in ("i2v", "t2v"):
                with self.subTest(step=step, mode=mode):
                    model, decoder, sample, mixer, values, ranges = run_step(step, mode)
                    self.assertEqual(ranges, [(.02, .999)])
                    self.assertTrue(values["fm_active"] and values["struct_active"] and values["temporal_active"])
                    self.assertTrue(values["shared_noise"])
                    self.assertFalse(values["fm_repair"])
                    self.assertFalse(values["repair"])
                    for name in ("fm", "struct", "temp"):
                        self.assertGreater(values[name], 0.)
                    self.assertAlmostEqual(values["sigma"], .8, places=6)
                    self.assertEqual(values["sigma"], values["temporal_sigma"])
                    self.assertAlmostEqual(values["weighted_fm"], values["fm"], places=6)
                    self.assertAlmostEqual(values["weighted_struct"], .1 * values["struct_noise_weight"] * values["struct"], places=6)
                    self.assertAlmostEqual(values["weighted_temp"], .05 * values["temp"], places=6)
                    self.assertEqual(len(model.calls), 1)
                    self.assertIsNotNone(model.calls[0]["guided"])
                    last = model.calls[-1]
                    expected = last["x"] - last["sigma"] * last["guided"]
                    # Conditional FM and CFG reconstruction are kept distinct,
                    # but both use the one shared noisy latent and sampled sigma.
                    target = (last["x"] - sample["latent"]) / last["sigma"]
                    error = last["cond"] - target
                    if mode == "i2v":
                        error = error[:, :, 1:]
                        expected[:, :, :1] = sample["first"]
                        for call in model.calls:
                            torch.testing.assert_close(call["x"][:, :, :1], sample["first"])
                    self.assertAlmostEqual(values["fm"], float(error.square().mean()), places=6)
                    self.assertEqual(len(decoder.inputs), 2)
                    torch.testing.assert_close(decoder.inputs[-1], expected)
                    combined = mixer.combine(.2)
                    terms = loss_breakdown([values], dict(fm=1., struct=.1, temp=.05), combined["aux_alpha"])
                    self.assertEqual(terms["loss_terms"]["fm"]["micro_weights"], [1.])
                    self.assertEqual(terms["loss_terms"]["temp"]["micro_weights"], [.05])
                    self.assertAlmostEqual(terms["loss_total"], values["fm"] + values["weighted_temp"] +
                                           combined["aux_alpha"] * values["weighted_struct"], places=6)
                    self.assertLessEqual(combined["aux_grad_share"], .200001)

    def test_generation_gradients_are_the_sum_of_fm_and_temp(self):
        for step in (1, 801):
            full = run_step(step, weights=dict(fm=1., struct=.1, temp=.05))
            fm = run_step(step, weights=dict(fm=1., struct=0., temp=0.))
            temp = run_step(step, weights=dict(fm=0., struct=0., temp=.05))
            for p, pf, pt in zip(full[0].adapter.parameters(), fm[0].adapter.parameters(), temp[0].adapter.parameters()):
                torch.testing.assert_close(p.grad, pf.grad + pt.grad, rtol=1e-5, atol=1e-7)
            self.assertGreater(sum(g.square().sum().item() for g in full[3].aux), 0.)
            self.assertEqual(sum(g.abs().sum().item() for g in fm[3].aux), 0.)
            self.assertGreater(sum(p.grad.abs().sum().item() for p in temp[0].adapter.parameters()), 0.)

    def test_step_801_keeps_the_same_shared_noise_recipe(self):
        before = run_step(800)
        after = run_step(801)
        self.assertEqual(len(before[0].calls), 1)
        self.assertEqual(len(after[0].calls), 1)
        self.assertEqual(before[4], after[4])
        for p, q in zip(before[0].adapter.parameters(), after[0].adapter.parameters()):
            torch.testing.assert_close(p.grad, q.grad, rtol=0, atol=0)

    def test_temporal_backprop_is_active_and_finite_across_the_full_noise_range(self):
        for mode in ("i2v", "t2v"):
            for sigma in (.02, .1, .5, .9, .9989):
                with self.subTest(mode=mode, sigma=sigma):
                    model, _, _, mixer, values, ranges = run_step(
                        1200, mode, weights=dict(fm=0., struct=0., temp=.05), sigma=sigma)
                    self.assertEqual(ranges, [(.02, .999)])
                    self.assertGreater(values["temp"], 0.)
                    grads = [p.grad for p in model.adapter.parameters() if p.grad is not None]
                    self.assertTrue(all(torch.isfinite(g).all() for g in grads))
                    self.assertGreater(sum(float(g.abs().sum()) for g in grads), 0.)
                    combined = mixer.combine(.2)
                    self.assertGreater(combined["generation_grad_all"], 0.)

    def test_struct_gradient_routes_only_to_cores_at_the_shared_sigma(self):
        model, _, _, mixer, values, _ = run_step(1)
        grads = [p.grad.clone() for p in model.adapter.parameters()]
        core = set(map(id, model.adapter.core_parameters()))
        combined = mixer.combine(.2)
        self.assertGreater(combined["effective_aux_grad"], 0.)
        for param, prior in zip(model.adapter.parameters(), grads):
            if id(param) not in core:
                torch.testing.assert_close(param.grad, prior, rtol=0, atol=0)
        self.assertAlmostEqual(values["struct_noise_weight"], ((1 - .8) / .5) ** 2, places=6)

    def test_checkpoint_cadence_exact_resume_and_final_inference_contract(self):
        records = [dict(category="unlabeled") for _ in range(17)]
        adapter = ToyAdapter()
        cfg = configuration()
        optimizer, ema, plan = optimizer_for(adapter, cfg), EMA(adapter), ExposurePlan(records, 42)
        assets = dict(test="batch1-assets")
        identity = dict(test="batch1-resume", code=digest(code_fingerprint()), assets=digest(assets))

        def update(a, opt, average, queue, step):
            exposure, = queue.batch(step)
            set_schedule(a, opt, cfg, step)
            opt.zero_grad(set_to_none=True)
            target = torch.rand(()) + random.random() + np.random.rand()
            sum((p - target).square().sum() for p in a.parameters()).backward()
            opt.step()
            average.update(a)
            return exposure

        with tempfile.TemporaryDirectory(dir=ROOT / "tmp") as tmp:
            checkpoints = {}
            for step in range(1, 1201):
                exposure = update(adapter, optimizer, ema, plan, step)
                if step in SAVE_STEPS:
                    checkpoints[step] = save_checkpoint(tmp, step, adapter, optimizer, ema, plan, cfg, identity)
                if step == 801:
                    expected = deepcopy((adapter.state_dict(), ema.state_dict(), optimizer.state_dict(), exposure, plan.state_dict()))
            self.assertEqual(sorted(p.name for p in Path(tmp).glob("step*")),
                             [f"step{step:04d}" for step in range(100, 1201, 100)])
            self.assertEqual(read_json(Path(tmp) / "final.json")["step"], 1200)
            infer = implementation()
            with patch.object(infer, "lock_assets", return_value=assets):
                self.assertEqual(infer.checkpoint_path(cfg, checkpoints[1200]), checkpoints[1200])
            self.assertEqual(infer.read_config(checkpoints[1200] / "config.json"), cfg)
            restored, queue = ToyAdapter(), ExposurePlan(records, 42)
            opt = optimizer_for(restored, cfg)
            completed, average, rng = load_training(checkpoints[800], restored, opt, queue, cfg, identity)
            self.assertEqual(completed, 800)
            restore_rng(rng)
            exposure = update(restored, opt, average, queue, 801)
            self.assertEqual(exposure, expected[3])
            self.assertEqual(queue.state_dict(), expected[4])
            for name, value in restored.state_dict().items():
                torch.testing.assert_close(value, expected[0][name], rtol=0, atol=0)
            for name, value in average.values.items():
                torch.testing.assert_close(value, expected[1]["values"][name], rtol=0, atol=0)
            for key, values in opt.state_dict()["state"].items():
                for name, value in values.items():
                    torch.testing.assert_close(value, expected[2]["state"][key][name], rtol=0, atol=0)
            with self.assertRaisesRegex(ValueError, "different training schedule"):
                original_optim.load_training(checkpoints[800], restored, opt, queue, cfg, identity)
            marker = read_json(checkpoints[400] / "complete.json")
            marker["training_recipe"] = original_optim.TRAINING_RECIPE
            save_json(marker, checkpoints[400] / "complete.json")
            with self.assertRaisesRegex(ValueError, "batch1 checkpoint"):
                load_training(checkpoints[400], restored, opt, queue, cfg, identity)

    def test_inference_reuse_does_not_patch_original_modules(self):
        from inference import infer as original
        old_recipe, old_reader, old_fingerprint = original.TRAINING_RECIPE, original.read_config, original.code_fingerprint
        shared = implementation()
        self.assertEqual(shared.TRAINING_RECIPE, TRAINING_RECIPE)
        self.assertIs(shared.read_config, configuration)
        self.assertIs(shared.code_fingerprint, code_fingerprint)
        self.assertEqual(original.TRAINING_RECIPE, old_recipe)
        self.assertIs(original.read_config, old_reader)
        self.assertIs(original.code_fingerprint, old_fingerprint)


if __name__ == "__main__":
    torch.set_num_threads(2)
    unittest.main()
