"""One persistent source queue; every exposure trains all three objectives."""
from copy import deepcopy

from physgen_v42.data import Queue

MODE_CYCLE = ("i2v", "i2v", "i2v", "t2v")


class ExposurePlan:
    def __init__(self, records, seed):
        if not records:
            raise ValueError("Batch1 requires a nonempty training dataset")
        self.records, self.seed = records, seed
        self.queue = Queue(records, seed)
        self.counts = [dict(i2v=0, t2v=0, temp=0) for _ in records]

    def batch(self, step):
        if step != self.queue.cursor + 1 or not 1 <= step <= 1200:
            raise ValueError("Batch1 exposure steps must be sequential in 1..1200")
        index = self.queue.next()
        mode = MODE_CYCLE[(step - 1) % len(MODE_CYCLE)]
        counts = self.counts[index]
        exposure = counts["i2v"] + counts["t2v"]
        counts[mode] += 1
        counts["temp"] += 1
        return [dict(index=index, mode=mode, exposure=exposure, temporal=True, repair=False)]

    def state_dict(self):
        return dict(seed=self.seed, cursor=self.queue.cursor, counts=deepcopy(self.counts))

    def validate_state(self, state, step):
        if (state.get("seed") != self.seed or state.get("cursor") != step or
                not isinstance(state.get("counts"), list) or len(state["counts"]) != len(self.records)):
            raise ValueError("Batch1 queue identity/coverage differs from the completed step")
        counts = state["counts"]
        for row in counts:
            if (set(row) != {"i2v", "t2v", "temp"} or
                    any(type(v) is not int or v < 0 for v in row.values()) or
                    row["temp"] != row["i2v"] + row["t2v"]):
                raise ValueError("Invalid batch1 per-source exposure counts")
        if (sum(c["temp"] for c in counts) != step or
                sum(c["t2v"] for c in counts) != step // 4 or
                sum(c["i2v"] for c in counts) != step - step // 4):
            raise ValueError("Batch1 requires one TEMP per step and a 3:1 mode cycle")

    def load_state_dict(self, state):
        step = state.get("cursor")
        if type(step) is not int or not 0 <= step <= 1200:
            raise ValueError("Invalid batch1 queue cursor")
        self.validate_state(state, step)
        self.queue = Queue(self.records, self.seed)
        self.queue.cursor = step
        self.counts = deepcopy(state["counts"])
