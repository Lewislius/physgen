独立的 v4.2 batch=1 训练版，复用原模型、2400 条缓存及训练/验证划分。batch1 的独立实现放在 `batch1/`；batch1 与正式 batch=8 均每 100 步保存 checkpoint。

2026-09-17 的 checkpoint 日志参数冲突已同步修复；旧→新代码指纹兼容和保存/续训回归测试见 [CHECKPOINT_RECOVERY.md](../CHECKPOINT_RECOVERY.md)。

启动训练：

```bash
cd /home/liuzhirui/Project/physGen/code/v4.2
det experiment create batch1/train_1x96g.yaml .
```

| 项目 | batch=1 行为 |
|---|---|
| 有效 batch | 每步只加载 1 条视频，accumulation=1，优化器只更新 1 次 |
| 共享噪声 | 每步只采样一次 sigma，均匀分布 0.02–0.999；只生成一个噪声张量，三类损失共享同一个带噪视频 |
| FM | 沿用条件预测与 velocity MSE，目标为 noise−GT |
| STRUCT | 复用同一次条件预测的中间观测及 sigma，沿用 detached 辅助路径与 teacher 目标 |
| TEMP | 在相同 sigma、带噪视频和条件上，沿用 CFG 的 xhat=x_sigma−sigma*v_cfg，通过可微 VAE 对齐 GT 帧间差分 |
| 1–1200 步 | 每步固定计算三类损失并参与梯度更新，TEMP 不设高/低噪声门限；801 步继续相同日程 |
| 损失 | `FM + 0.10*aux_alpha*q(sigma_fm)*STRUCT + 0.05*TEMP`；不再除以 8 |
| 梯度 | FM、TEMP 梯度累加，STRUCT 仍仅更新两个 core，并按原全局 20% 上限合并；之后裁剪和 AdamW |
| I2V/T2V | 连续 4 步按 I2V、I2V、I2V、T2V；1200 步共 900/300 条次 |
| 训练日程 | 1200 步；沿用原学习率、前 50 步预热及余弦衰减，EMA 每步更新 |
| 验证／保存 | 每 200 步沿用原健康检查；每 100 步保存完整可恢复 checkpoint，直到第 1200 步 |

每步只调用一次 `ProcessWan`，其内部沿用 CFG 的条件/无条件预测。FM 与 TEMP 的加权和一次反传；STRUCT 每步通过 `autograd.grad` 计算两个 core 的辅助梯度，再经原 `GradientMixer` 合并。之后才执行一次裁剪、AdamW 和 EMA 更新，不把 STRUCT 的梯度改接到 writer/TextInit。

`sigma`、`sigma_fm`、`sigma_struct`、`sigma_temp` 均是同一个采样值；日志标注 `shared_noise=true`。`micro.jsonl` 每步一条，`updates.jsonl` 的三项贡献对应实际梯度权重；`TOTAL` 固定本步 aux_alpha、按既定梯度路由解释。健康检查沿用原 FM/STRUCT 留出验证，不额外做 VAE TEMP 验证。

原版 STRUCT 的 `q(sigma)=clamp((1−sigma)/0.5,0,1)^2` 保留：它仍在每步计算并反传，但高噪声时权重较小。TEMP 始终使用原系数 0.05，无噪声门控。为了让所有 1200 步都遵守同一个采样区间，本版取消了先前草稿在第 801 步启用的低噪声 repair 前向。

默认 `PREPARE=1`：先检查训练 GPU；已完成缓存直接复用，缺失时调用原预处理流程逐组件补齐，不另建 batch1 缓存。可用 `PREPARE=0` 跳过准备。模型、VAE/T5/JEPA/首帧 anchor 缓存、统计量和数据划分都与原版一致。

输出独立保存：

- checkpoint：`checkpoints/batch1/<run>/step0100`、`step0200`、…、`step1200`。
- 最终指针：`checkpoints/batch1/latest_final.json`。
- 日志：`train/train_log/batch1/<run>/`。
- 生成结果：`inference_outputs/batch1/`。

恢复命令中替换成实际运行目录；只接受本 batch1 版本的 checkpoint，不能把 batch8/quick16 的优化器与曝光队列当作本版断点：

```bash
det experiment create batch1/train_1x96g.yaml . \
  --config 'environment.environment_variables=["RESUME=/home/liuzhirui/Project/physGen/code/v4.2/checkpoints/batch1/实际run目录/step0800","OMP_NUM_THREADS=4"]'
```

训练完成后的推理入口复用原推理、teacher 和报告流程，采用本版配置／recipe／源码校验，并读取独立的最终指针：

```bash
det experiment create batch1/infer_1x96g.yaml .
```

仅检查配置及缓存就绪状态，不需要 GPU：

```bash
/home/liuzhirui/miniconda3/envs/moviestory/bin/python -I -B batch1/train.py --check-config
```

梯度冲突源于目标不同，并不要求噪声不同。若同一参数增大能改善速度预测，却损害结构或帧间差分，那么两项梯度在该方向上相反；整体可用梯度内积是否小于 0 判断。共享视频与噪声可以去掉独立采样带来的部分差异，不能保证三项目标一致，也不能由此断言当前训练已经出现有害冲突。

高噪声 TEMP 需要观察实际效果：`dxhat/dv_cfg=−sigma`，而高噪声的一步重建可能更不准确，因此原来 0.05 的权重不保证仍有合适的梯度尺度。按本次要求先固定范围与系数；全局梯度裁剪限制总范数，STRUCT 的 20% 上限仅约束辅助结构梯度，两者都不保证 FM/TEMP 同向。CPU 小模型验证只能检查实现与数值，不能证明完整 VAE/5B 模型在全噪声下稳定或生成效果改善。

batch=1 的 1200 步只有 1200 条训练曝光，原 batch=8 为 9600 条次。BS1 每步计算更少，但 FM/STRUCT 只用一个样本估计期望，更新一般更波动；BS8 的 FM/STRUCT 平均 8 个样本，TEMP 原本也仅有 1 个。原版使用 microbatch=1 累积 8 次，因此 BS1 的峰值显存不应预期降为八分之一。两版同时改变了曝光数和噪声配比，比较时需记录训练时间与验证表现，不能将质量变化全部归因于 batch 大小。

本版使用有独立源码身份的训练 recipe：`fm_joint_bs1_shared_fullnoise_all_losses_v1`。CPU 数值、断点恢复和原版回归检查的结果见 [verification.json](verification.json)；完整 5B GPU 训练与生成质量需要实际任务验证。
