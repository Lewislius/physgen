"""Batch-one completion markers and exact resume; batch-eight checkpoints are rejected."""
import math
from pathlib import Path

import torch

from batch1 import TRAINING_RECIPE
from physgen_v42 import VERSION
from physgen_v42.optim import EMA, SCHEDULE_FORMULA, lr_factor, rng_state
from physgen_v42.runtime import (checkpoint_identity_compatible, digest, file_identity, read_json,
                                save_json, save_tensor, verify_files)

SAVE_STEPS = tuple(range(100, 1201, 100))


def save_checkpoint(root, step, adapter, optimizer, ema, plan, cfg, identity):
    if (step not in SAVE_STEPS or ema is None or ema.updates != step or
            cfg["train"]["recipe"] != TRAINING_RECIPE or cfg["train"]["accumulation"] != 1):
        raise ValueError("Batch1 saves every 100 steps through step 1200 with one EMA update per step")
    plan.validate_state(plan.state_dict(), step)
    path = Path(root) / f"step{step:04d}"
    path.mkdir(parents=True, exist_ok=True)
    if (path / "complete.json").exists():
        raise FileExistsError(f"Refusing to overwrite completed checkpoint: {path}")
    save_json(cfg, path / "config.json")
    save_tensor(adapter.state_dict(), path / "adapter.pt")
    save_tensor(dict(step=step, optimizer=optimizer.state_dict(), ema=ema.state_dict(),
                     plan=plan.state_dict(), rng=rng_state(), training_recipe=TRAINING_RECIPE,
                     identity=identity, version=VERSION,
                     scheduler=dict(completed_step=step, formula=SCHEDULE_FORMULA,
                                    group_lr=[g["lr"] for g in optimizer.param_groups])), path / "training.pt")
    values = {k: v.detach().cpu() for k, v in adapter.state_dict().items()}
    values.update({k: v.detach().cpu() for k, v in ema.values.items()})
    save_tensor(values, path / "ema.pt")
    names = ("config.json", "adapter.pt", "training.pt", "ema.pt")
    save_json(dict(step=step, version=VERSION, identity=identity, training_recipe=TRAINING_RECIPE,
                   ema_updates=ema.updates, batch_size=1,
                   files={name: file_identity(path / name) for name in names}), path / "complete.json")
    if step == 1200:
        save_json(dict(checkpoint=str(path.resolve()), step=step), Path(root) / "final.json")
    return path


def load_training(path, adapter, optimizer, plan, cfg, identity):
    path = Path(path)
    complete = read_json(path / "complete.json")
    if complete.get("training_recipe") != TRAINING_RECIPE or complete.get("batch_size") != 1:
        raise ValueError("Expected a batch1 checkpoint; batch8/quick16 cannot be resumed here")
    if complete["version"] != VERSION or not checkpoint_identity_compatible(complete["identity"], identity):
        raise ValueError("Batch1 checkpoint architecture/data/assets/code differ")
    verify_files(path, complete["files"], full=True)
    if digest(read_json(path / "config.json")) != digest(cfg):
        raise ValueError("Cannot resume with a changed batch1 configuration")
    # Locally produced trusted checkpoint; the RNG state includes Python/NumPy objects.
    state = torch.load(path / "training.pt", map_location="cpu", weights_only=False)
    step = state["step"]
    if (step not in SAVE_STEPS or step != complete["step"] or state["version"] != VERSION or
            state["identity"] != complete["identity"] or state.get("training_recipe") != TRAINING_RECIPE):
        raise ValueError("Batch1 completion marker and training state disagree")
    plan.validate_state(state["plan"], step)
    if (state["ema"] is None or state["ema"]["updates"] != step or
            complete["ema_updates"] != step or state["ema"]["decay"] != cfg["train"]["ema_decay"]):
        raise ValueError("Batch1 EMA differs from the completed schedule")
    scheduler = state["scheduler"]
    expected_lr = [cfg["train"]["peak_lr"][g["name"]] * lr_factor(step, g["name"])
                   for g in optimizer.param_groups]
    saved_groups = state["optimizer"]["param_groups"]
    if (scheduler["completed_step"] != step or scheduler["formula"] != SCHEDULE_FORMULA or
            len(scheduler["group_lr"]) != len(expected_lr) or len(saved_groups) != len(expected_lr) or
            any(not math.isclose(actual, expected, rel_tol=1e-12)
                for actual, expected in zip(scheduler["group_lr"], expected_lr)) or
            any(saved["name"] != group["name"] or not math.isclose(saved["lr"], expected, rel_tol=1e-12)
                for saved, group, expected in zip(saved_groups, optimizer.param_groups, expected_lr))):
        raise ValueError("Batch1 optimizer/scheduler differs from its completed step")
    adapter.load_state_dict(torch.load(path / "adapter.pt", map_location="cpu", weights_only=True), strict=True)
    optimizer.load_state_dict(state["optimizer"])
    plan.load_state_dict(state["plan"])
    ema = EMA(adapter, cfg["train"]["ema_decay"])
    ema.load_state_dict(state["ema"])
    for param_state in optimizer.state.values():
        for name in ("exp_avg", "exp_avg_sq"):
            if name in param_state and param_state[name].dtype != torch.float32:
                raise ValueError("Adam moments must remain FP32")
    # The caller restores RNG only after constructors of the frozen models finish.
    return step, ema, state["rng"]
