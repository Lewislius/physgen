"""Reuse the original inference pipeline in a separate module namespace for BS1 checkpoints."""
import importlib.util
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from batch1 import TRAINING_RECIPE
from batch1.config import DEFAULT_CONFIG, code_fingerprint, configuration
from physgen_v42.runtime import ROOT


def implementation():
    # Do not patch inference.infer or physgen_v42 globals: other callers keep BS8.
    spec = importlib.util.spec_from_file_location("batch1._shared_inference", ROOT / "inference/infer.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.TRAINING_RECIPE = TRAINING_RECIPE
    module.read_config = configuration
    module.code_fingerprint = code_fingerprint
    return module


def main():
    if not any(arg == "--config" or arg.startswith("--config=") for arg in sys.argv[1:]):
        sys.argv.extend(["--config", str(DEFAULT_CONFIG)])
    implementation().main()


if __name__ == "__main__":
    main()
