"""CPU checks for reporting the real mixed objective without verbose stdout."""
import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch

from physgen_v42.losses import auxiliary_objective, generation_objective, struct_noise_weight
from physgen_v42.optim import GradientMixer
from physgen_v42.runtime import ROOT, log
from physgen_v42.training_log import TrainingProgress, format_losses, loss_breakdown


WEIGHTS = dict(fm=1., struct=.1, temp=.05)


def example_step(max_share=.2, zero_generation=False):
    """Use real backward/mixing on two toy parameter groups with varied noise."""
    core = torch.nn.Linear(1, 1, bias=False).double()
    core.weight.data.fill_(.7)
    writer = torch.tensor(1.2, dtype=torch.float64, requires_grad=True)
    mixer = GradientMixer(core, [*core.parameters(), writer])
    metrics, originals = [], []
    for i in range(8):
        sigma = torch.tensor((.05, .15, .3, .5, .6, .7, .85, .999)[i], dtype=torch.float64)
        struct = (core.weight.squeeze() - (i + 1) * 20).square()
        fm = (core.weight.squeeze() + writer - i / 5).square()
        temp = (core.weight.squeeze() * writer - .3).square() if i == 7 else fm * 0
        if zero_generation:
            fm, temp = fm * 0, temp * 0
        generation_objective(fm, temp).backward()
        weighted_struct = auxiliary_objective(struct, sigma)
        mixer.accumulate_aux(weighted_struct)
        values = dict(fm=float(fm.detach()), struct=float(struct.detach()),
                      temp=float(temp.detach()), fm_active=True,
                      temporal_active=i == 7,
                      struct_noise_weight=float(struct_noise_weight(sigma)),
                      weighted_fm=float(fm.detach()) / 8,
                      weighted_struct=float(weighted_struct.detach()),
                      weighted_temp=.05 * float(temp.detach()))
        metrics.append(values)
        originals.append(float(sigma))
    combined = mixer.combine(max_share=max_share)
    values = loss_breakdown(metrics, WEIGHTS, combined["aux_alpha"])
    return core, writer, metrics, originals, combined, values


class TrainingLoggingTests(unittest.TestCase):
    def test_effective_total_matches_routed_backward(self):
        # Cover limited/unlimited auxiliary gradients and alpha=0.
        for ratio, zero in ((.2, False), (.999999, False), (.2, True)):
            with self.subTest(ratio=ratio, zero_generation=zero):
                core, writer, metrics, sigmas, combined, values = example_step(ratio, zero)
                alpha = combined["aux_alpha"]
                if ratio == .2 and not zero:
                    self.assertGreater(alpha, 0)
                    self.assertLess(alpha, 1)
                p = torch.tensor(.7, dtype=torch.float64, requires_grad=True)
                w = torch.tensor(1.2, dtype=torch.float64, requires_grad=True)
                expected = p * 0
                for i, sigma in enumerate(sigmas):
                    q = max(0., min(1., (1 - sigma) / .5)) ** 2
                    expected = expected + .1 * alpha * q * (p - (i + 1) * 20).square() / 8
                    if not zero:
                        expected = expected + (p + w - i / 5).square() / 8
                        if i == 7:
                            expected = expected + .05 * (p * w - .3).square()
                self.assertAlmostEqual(values["loss_total"], float(expected.detach()), places=6)
                expected.backward()
                torch.testing.assert_close(core.weight.grad.squeeze(), p.grad, rtol=2e-6, atol=2e-6)
                if not zero:
                    torch.testing.assert_close(writer.grad, w.grad)
                self.assertEqual(values["loss_struct"], alpha * values["loss_struct_nominal"])
                for term in values["loss_terms"].values():
                    self.assertAlmostEqual(sum(term["micro_contributions"]), term["contribution"], places=6)
                struct = values["loss_terms"]["struct"]
                self.assertAlmostEqual(struct["noise_weighted_mean"] * struct["effective_weight"],
                                       struct["contribution"], places=6)
                self.assertNotAlmostEqual(sum(struct["noise_weights"]) / 8 * struct["raw_mean"],
                                          struct["noise_weighted_mean"], places=3)
                for i, micro in enumerate(metrics):
                    for name in ("fm", "struct", "temp"):
                        term = values["loss_terms"][name]
                        self.assertAlmostEqual(term["micro_weights"][i] * micro[name],
                                               term["micro_contributions"][i], places=6)

    def test_fm_stays_active_when_auxiliary_budget_is_zero(self):
        *_, values = example_step(zero_generation=True)
        line = format_losses(values)
        self.assertNotIn("FM(off", line)
        self.assertEqual(values["loss_terms"]["fm"]["effective_weight"], 1.)
        self.assertEqual(values["loss_struct"], 0.)
        self.assertEqual(values["loss_total"], 0.)

    def test_temporal_contribution_is_not_averaged_over_eight(self):
        _, _, metrics, _, _, values = example_step()
        self.assertAlmostEqual(values["loss_temp"], .05 * metrics[-1]["temp"])
        self.assertEqual(values["loss_terms"]["temp"]["micro_weights"], [0.] * 7 + [.05])

    def test_verbose_records_are_saved_without_console_output(self):
        stream = io.StringIO()
        with tempfile.TemporaryDirectory(dir=ROOT / "tmp") as directory:
            path = Path(directory) / "micro.jsonl"
            payload = dict(event="micro", step=101, interventions=dict(frame_ratios=list(range(31))))
            with contextlib.redirect_stdout(stream):
                log(path, console=False, **payload)
            self.assertEqual(stream.getvalue(), "")
            self.assertEqual(json.loads(path.read_text()), payload)
            # Preparation and quick16 callers keep their original default behavior.
            with contextlib.redirect_stdout(stream):
                log(event="encoded", stage="vae", count=25)
            self.assertEqual(json.loads(stream.getvalue())["count"], 25)

    def test_progress_in_cluster_logs_and_terminal(self):
        *_, values = example_step()
        for terminal in (False, True):
            with self.subTest(terminal=terminal):
                stream = io.StringIO()
                stream.isatty = lambda: terminal
                with TrainingProgress(1200, stream) as progress:
                    progress.start_step(601, 8)
                    for count in range(1, 9):
                        progress.advance(count)
                    progress.finish_step(values)
                output = stream.getvalue()
                self.assertIn("step 601/1200", output)
                self.assertIn("micro [################] 8/8", output)
                self.assertIn("STRUCT(qL=", output)
                self.assertIn("TOTAL=", output)
                self.assertNotIn("interventions", output)
                self.assertEqual(output.count("TOTAL="), 1)
                self.assertEqual(output.count("\n"), 1 if terminal else 9)
                self.assertEqual("\r" in output, terminal)


if __name__ == "__main__":
    unittest.main()
