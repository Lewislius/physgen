"""Critical delta-H contracts: correction targets, gradient routes and interventions."""
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(Path(__file__).resolve().parent))
import torch
from test_independent_correctors import fixture
from physgen_v42.geometry import Geometry,fit_geometry
from physgen_v42.model import Adapter
from physgen_v42.monitoring import residual_profile,register_write_credit
from physgen_v42.write_supervision import paired_repair_input,writer_repair_loss


class DeltaHRepairTests(unittest.TestCase):
    def test_profile_excludes_padding_and_known_slice(self):
        d=torch.ones(1,3,4,2)*.1
        d[:,0]=100; d[:,:,3]=100
        profile=residual_profile(d,torch.ones_like(d),torch.tensor([1.,1.,1.,0.]),
                                 torch.tensor([0.,.5,1.]),2.,first_known=True,grid_hw=(2,2),maps=True)
        self.assertAlmostEqual(profile['token_ratio_max'],.1,places=6)
        self.assertEqual(profile['frame_valid'],[False,True,True])
        self.assertAlmostEqual(profile['temporal_rms_per_second'],0.)
        self.assertAlmostEqual(profile['spatial_neighbor_rms'],0.)

    def test_write_credit_has_correct_sign_and_accumulation(self):
        before=torch.tensor([1.])
        after=torch.tensor([1.2],requires_grad=True)
        metrics={}
        register_write_credit(after,before,metrics,8.)
        ((after-2).square()/8).backward()
        self.assertAlmostEqual(metrics['fm_write_credit']['dloss_dscale'],-.32,places=6)

    def test_repair_endpoint_target_and_first_slice(self):
        geo=Geometry.build(dict(fit_geometry(64,64,64,64),frames=9),torch.device('cpu'))
        clean=torch.randn(1,4,3,4,4); noise=torch.randn_like(clean); first=clean[:,:,:1].clone()
        sigma=torch.tensor(.4)
        ref,x,target,info=paired_repair_input(clean,noise,sigma,first,geo,
            dict(clean_probability=0.,max_relative_strength=.2,warp_latent_pixels=.5))
        torch.testing.assert_close(x[:,:,0],first[:,:,0],rtol=0,atol=0)
        torch.testing.assert_close((x-sigma*target)[:,:,1:],clean[:,:,1:],rtol=1e-5,atol=1e-6)
        self.assertGreater(info['relative_input_rms'],0)

    def test_trajectory_conditions_and_struct_gradient(self):
        cfg,old,geo=fixture()
        cfg['state']['initializer']='condition_trajectory_v1'
        # Fixture's position is zero: explicit nonidentical temporal positions.
        geo.position=lambda phase,xy,width: (phase[:,None]*torch.tensor([1.,-1.,2.,-2.])[None])[None,:,None,:].expand(1,2,2,width)
        model=Adapter(cfg,{k:getattr(old,k) for k in ('mu_first','s_z','s_v')},hidden=4,text_dim=4,spatial=2)
        text=torch.randn(1,3,4); anchor=torch.randn(2,4)
        initial=model.initialize(text,geo,'i2v',anchor,duration=3.)
        torch.testing.assert_close(initial,anchor[None,None].expand(1,2,2,4),rtol=0,atol=0)
        (initial-1).square().mean().backward()
        self.assertGreater(float(model.text_init.output[-1].weight.grad.norm()),0.)
        with torch.no_grad(): model.text_init.output[-1].weight.normal_(0,.1)
        changed=model.initialize(text,geo,'i2v',anchor,duration=3.)
        self.assertGreater(float((changed[:,1]-changed[:,0]).detach().abs().max()),1e-6)
        self.assertGreater(float((changed-model.initialize(text+1,geo,'i2v',anchor,duration=3.)).detach().abs().max()),1e-6)
        with self.assertRaises(ValueError): model.initialize(text,geo,'t2v',anchor)

    def test_writer_target_routes_only_to_writer_and_preserves_valid_teacher(self):
        _,model,geo=fixture(); writer=model.correctors['5'].writer
        h=torch.randn(1,4,4,requires_grad=True); p=torch.randn(1,2,2,4,requires_grad=True)
        sigma=torch.tensor(.5)
        reference=h.detach()+.01
        loss,report=writer_repair_loss(writer,h,p,h,reference,sigma,geo,False,5,5.)
        loss.backward()
        self.assertLessEqual(report['target_feasibility_max'],.950001)
        self.assertIsNone(h.grad); self.assertIsNone(p.grad)
        self.assertGreater(float(writer.output.weight.grad.norm()),0.)
        with torch.no_grad(): writer.output.weight.normal_(0,.001)
        prediction,_=writer(h,p,h,sigma,1.,False,5,geo)
        same,report=writer_repair_loss(writer,h,p,h,prediction.detach(),sigma,geo,False,5,5.)
        self.assertLess(float(same.detach()),1e-10)
        half,_=writer(h,p,h,sigma,1.,False,5,geo,strength=.5)
        zero,_=writer(h,p,h,sigma,1.,False,5,geo,strength=0.)
        torch.testing.assert_close(half-h,.5*(prediction-h),rtol=1e-4,atol=2e-7)
        torch.testing.assert_close(zero,h,rtol=0,atol=0)


if __name__=='__main__':
    torch.set_num_threads(2)
    unittest.main()
