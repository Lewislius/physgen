"""CPU regression checks for FM from step 1 and the retained repair boundary."""
from contextlib import nullcontext
from pathlib import Path
import random
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch

from physgen_v42.data import ExposurePlan
from physgen_v42.model import Writer
from physgen_v42.optim import (EMA, GradientMixer, TRAINING_RECIPE, load_training, optimizer_for,
                              ramp, restore_rng, save_checkpoint, set_schedule)
from physgen_v42.runtime import ROOT, read_json, save_json
from quick16.run import configuration
from quick16.training import batches
from train import train as training


class TinyAdapter(torch.nn.Module):
    def __init__(self):
        super().__init__()
        for i, name in enumerate(("core", "text_init", "writer5", "writer15"), 1):
            module = torch.nn.Linear(1, 1, bias=False)
            module.weight.data.fill_(i / 5)
            setattr(self, name, module)
        self.register_buffer("s_z", torch.tensor(1.))

    def groups(self):
        return {name: getattr(self, name) for name in ("core", "text_init", "writer5", "writer15")}

    def initialize(self, text, geo, mode, anchor):
        return self.text_init(text)

    def auxiliary(self, p0, observations, text, sigma, duration, geo):
        return self.core(p0.detach() + observations[0].detach()).reshape(1, 1, 1, 1)


class TinyModel:
    def __init__(self):
        self.adapter, self.calls = TinyAdapter(), []

    def __call__(self, x, first, text, sigma, duration, geo, p0, negative=None, budget=1.):
        a = self.adapter
        correction = a.writer15(a.writer5(a.core(p0))).reshape(1, 1, 1, 1, 1)
        cond = (.2 + budget * correction) * x
        guided = cond + .25 * x if negative is not None else None
        self.calls.append(dict(x=x.detach().clone(), sigma=sigma.detach().clone(),
                               cond=cond.detach().clone(), guided=None if guided is None else guided.detach().clone(),
                               grad_enabled=torch.is_grad_enabled()))
        return dict(cond=cond, guided=guided, p0=p0.detach(),
                    observations=(x.detach().mean().reshape(1, 1),), metrics={})

    def observe(self, *args):
        raise AssertionError("STRUCT-only warmup must not be used")


class TinyDecoder:
    def __init__(self):
        self.inputs = []

    def views(self, latent, specs):
        self.inputs.append(latent.detach().clone())
        return dict(global_rgb=latent[0].permute(1, 0, 2, 3), out_of_range=latent.new_zeros(()))


def micro(step, temporal=True):
    torch.manual_seed(37)
    model, decoder = TinyModel(), TinyDecoder()
    latent = torch.randn(1, 3, 5, 2, 2)
    sample = dict(latent=latent, first=None, text=torch.ones(1, 1), anchor=None,
                  target=torch.zeros(1, 1, 1, 1), instances=None,
                  record=dict(duration=.2, objects_reliable=False,
                              geometry=dict(h=2, w=2, rh=2, rw=2, top=0, left=0, frames=5)))
    exposure = dict(mode="t2v", temporal=temporal, repair=temporal and step >= 801, exposure=0)
    mixer = GradientMixer(model.adapter.core, model.adapter.parameters())
    geo = SimpleNamespace(p_weight=torch.ones(1))
    with patch.object(training.Geometry, "build", return_value=geo), \
            patch.object(training, "autocast", side_effect=lambda device: nullcontext()):
        values = training.train_micro(model, decoder, sample, exposure, step, mixer, torch.zeros(1, 1))
    combined = mixer.combine()
    return model, decoder, sample, values, combined


class JointScheduleTests(unittest.TestCase):
    def test_same_forward_losses_and_gradients_from_step1_through_800(self):
        previous = None
        for step in (1, 50, 100, 101, 200, 800):
            with self.subTest(step=step):
                model, decoder, sample, values, combined = micro(step)
                self.assertTrue(values["fm_active"])
                self.assertTrue(values["temporal_active"])
                self.assertFalse(values["repair"])
                self.assertGreater(values["fm"], 0.)
                self.assertGreater(values["temp"], 0.)
                self.assertEqual(len(model.calls), 1)
                self.assertTrue(model.calls[0]["grad_enabled"])
                self.assertEqual(len(decoder.inputs), 2)
                call = model.calls[0]
                torch.testing.assert_close(decoder.inputs[1], call["x"] - call["sigma"] * call["guided"])
                self.assertGreater(model.adapter.writer5.weight.grad.abs().sum().item(), 0.)
                self.assertGreater(model.adapter.writer15.weight.grad.abs().sum().item(), 0.)
                current = (values, combined, [p.grad.clone() for p in model.adapter.parameters()])
                if previous is not None:
                    self.assertEqual(current[:2], previous[:2])
                    for a, b in zip(current[2], previous[2]):
                        torch.testing.assert_close(a, b, rtol=0, atol=0)
                previous = current

    def test_repair_801_changes_only_the_temporal_sample(self):
        model, decoder, sample, values, _ = micro(801)
        self.assertEqual(len(model.calls), 2)
        before, after = model.calls
        self.assertFalse(before["grad_enabled"])
        self.assertTrue(after["grad_enabled"])
        torch.testing.assert_close(after["sigma"], .8 * before["sigma"])
        torch.testing.assert_close(after["x"], before["x"] + (after["sigma"] - before["sigma"]) * before["guided"])
        target = (after["x"] - sample["latent"]) / after["sigma"]
        self.assertAlmostEqual(values["fm"], float((after["guided"] - target).square().mean()), places=5)
        torch.testing.assert_close(decoder.inputs[1], after["x"] - after["sigma"] * after["guided"])
        self.assertTrue(values["fm_active"] and values["repair"] and values["temporal_active"])
        ordinary_model, ordinary_decoder, _, ordinary, _ = micro(801, temporal=False)
        self.assertEqual(len(ordinary_model.calls), 1)
        self.assertEqual(ordinary_decoder.inputs, [])
        self.assertTrue(ordinary["fm_active"])
        self.assertFalse(ordinary["repair"])

    def test_zero_initialized_writer_has_fm_gradient_at_step1(self):
        torch.manual_seed(11)
        writer = Writer(width=4, inner=4, hidden=4, heads=1)
        geo = SimpleNamespace(h_phase=torch.tensor([0., 1.]), p_phase=torch.tensor([0., 1.]),
                              h_weight=torch.ones(2), p_weight=torch.ones(2), h_xy=torch.zeros(2, 2),
                              p_xy=torch.zeros(2, 2),
                              position=lambda *args: torch.zeros(1, 2, 2, 4))
        h, state = torch.randn(1, 4, 4), torch.randn(1, 2, 2, 4)
        out, _ = writer(h, state, h, torch.tensor(.1), ramp(1), False, 5, geo)
        torch.testing.assert_close(out, h, rtol=0, atol=0)
        (out - .5 * h).square().mean().backward()
        self.assertGreater(writer.output.weight.grad.abs().sum().item(), 0.)
        adapter = TinyAdapter().requires_grad_(False)
        cfg = dict(train=dict(peak_lr={name: 1e-4 for name in adapter.groups()}))
        optimizer = optimizer_for(adapter, cfg)
        set_schedule(adapter, optimizer, cfg, 1)
        self.assertTrue(all(p.requires_grad for p in adapter.parameters()))
        self.assertTrue(all(g["lr"] > 0 for g in optimizer.param_groups))
        self.assertEqual([ramp(step) for step in (1, 100, 101, 800, 801)], [1.] * 5)

    def test_every_update_has_eight_fm_exposures_and_one_temporal(self):
        plan = ExposurePlan([dict(category="unlabeled") for _ in range(64)], 42)
        temporal_modes = []
        for step in range(1, 1201):
            exposures = plan.batch(step)
            self.assertEqual(len(exposures), 8)
            self.assertEqual(sum(e["mode"] == "i2v" for e in exposures), 6)
            temporal = [e for e in exposures if e["temporal"]]
            self.assertEqual(len(temporal), 1)
            self.assertEqual(sum(e["repair"] for e in exposures), int(step >= 801))
            temporal_modes.append(temporal[0]["mode"])
        for start in range(0, 1200, 4):
            self.assertEqual(temporal_modes[start:start + 4].count("t2v"), 1)
        self.assertEqual(plan.ordinary.cursor, 8400)
        self.assertEqual(plan.temporal.cursor, 1200)

    def test_resume_800_matches_uninterrupted_repair801(self):
        adapter = TinyAdapter()
        cfg = dict(train=dict(recipe=TRAINING_RECIPE, ema_decay=.995,
                              peak_lr={name: 1e-4 for name in adapter.groups()}))
        optimizer, ema = optimizer_for(adapter, cfg), EMA(adapter)
        records = [dict(category="unlabeled") for _ in range(32)]
        plan, identity = ExposurePlan(records, 42), dict(test="joint-training-resume")

        def update(a, opt, average, queue, step):
            exposures = queue.batch(step)
            set_schedule(a, opt, cfg, step)
            opt.zero_grad()
            target = torch.rand(()) + random.random() + np.random.rand()
            sum((p - target).square().sum() for p in a.parameters()).backward()
            opt.step()
            average.update(a)
            return exposures

        for step in range(1, 801):
            update(adapter, optimizer, ema, plan, step)
        with tempfile.TemporaryDirectory(dir=ROOT / "tmp") as directory:
            checkpoint = save_checkpoint(directory, 800, adapter, optimizer, ema, plan, cfg, identity)
            expected_exposures = update(adapter, optimizer, ema, plan, 801)
            resumed = TinyAdapter()
            resumed_opt, resumed_plan = optimizer_for(resumed, cfg), ExposurePlan(records, 42)
            step, resumed_ema, rng = load_training(checkpoint, resumed, resumed_opt, resumed_plan, cfg, identity)
            self.assertEqual(step, 800)
            self.assertEqual(resumed_ema.updates, 800)
            restore_rng(rng)
            self.assertEqual(update(resumed, resumed_opt, resumed_ema, resumed_plan, 801), expected_exposures)
            for name, value in adapter.state_dict().items():
                torch.testing.assert_close(resumed.state_dict()[name], value, rtol=0, atol=0)
            for name, value in ema.values.items():
                torch.testing.assert_close(resumed_ema.values[name], value, rtol=0, atol=0)
            self.assertEqual(resumed_ema.updates, 801)
            self.assertTrue(all(int(state["step"]) == 801 for state in resumed_opt.state.values()))
            marker = read_json(checkpoint / "complete.json")
            marker.pop("training_recipe")
            save_json(marker, checkpoint / "complete.json")
            with self.assertRaisesRegex(ValueError, "different training schedule"):
                load_training(checkpoint, resumed, resumed_opt, resumed_plan, cfg, identity)

    def test_quick16_uses_the_new_schedule_and_keeps_two_epochs(self):
        cfg = configuration(ROOT / "configs/quick16.yaml")
        counts, repairs = [0] * 12, 0
        for step, epoch, schedule_step, exposures in batches(cfg):
            self.assertEqual(sum(e["temporal"] for e in exposures), 1)
            self.assertEqual(sum(e["mode"] == "t2v" for e in exposures), 1)
            self.assertEqual(sum(e["repair"] for e in exposures), int(schedule_step >= 801))
            repairs += sum(e["repair"] for e in exposures)
            for exposure in exposures:
                counts[exposure["index"]] += 1
        self.assertEqual(counts, [2] * 12)
        self.assertEqual(repairs, 3)


if __name__ == "__main__":
    unittest.main()
