"""Focused checks for the corrected recipe's limits, gradients and resume state."""
import copy
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import torch
from test_independent_correctors import fixture
from physgen_v42.data import UniformExposurePlan
from physgen_v42.losses import v4_struct_coefficient
from physgen_v42.model import Adapter
from physgen_v42.optim import (EMA, GATED_RECIPE, GradientMixer, load_training,
                              optimizer_for, save_checkpoint, set_schedule)
from physgen_v42.runtime import read_config


def gated_fixture():
    cfg, original, geo = fixture()
    cfg['state']['write_gate'] = True
    cfg['train'].update(recipe=GATED_RECIPE, ema_decay=.995)
    stats = {k: getattr(original, k) for k in ('mu_first', 's_z', 's_v')}
    return cfg, Adapter(cfg, stats, hidden=4, text_dim=4, spatial=2), geo


class CorrectedTrainingTests(unittest.TestCase):
    def test_v4_coefficient_limits_and_fixed_paths(self):
        cfg = read_config(ROOT / 'configs/stability.yaml')
        old = read_config(ROOT / 'checkpoints/stability_20260917T113347Z_5d0494/step0100/config.json')
        self.assertEqual(cfg['paths'], old['paths'])
        self.assertEqual(cfg['data'], old['data'])
        weights = cfg['loss']
        sigmas = torch.tensor([0., .6, .8, .85, .98, 1.])
        torch.testing.assert_close(v4_struct_coefficient(sigmas, 200, weights),
                                   torch.tensor([.1, .1, .1, .075, .01, 0.]))
        torch.testing.assert_close(v4_struct_coefficient(sigmas, 100, weights),
                                   v4_struct_coefficient(sigmas, 200, weights) * .5)
        self.assertEqual(cfg['loss']['temp'], 0.)

    def test_gate_does_not_block_zero_writer_learning(self):
        _, adapter, geo = gated_fixture()
        writer = adapter.correctors['5'].writer
        h, p = torch.randn(1, 4, 4), torch.randn(1, 2, 2, 4)
        optimizer = torch.optim.SGD(writer.parameters(), lr=.1)
        out, metrics = writer(h, p, h, torch.tensor(.5), 1., False, 5, geo)
        torch.testing.assert_close(out, h, rtol=0, atol=0)
        self.assertEqual(metrics['gate_mean'], .5)
        (out - .5*h).square().mean().backward()
        self.assertGreater(writer.output.weight.grad.norm().item(), 0.)
        optimizer.step()
        optimizer.zero_grad()
        out, metrics = writer(h, p, h, torch.tensor(.5), 1., False, 5, geo)
        (out - .5*h).square().mean().backward()
        self.assertGreater(writer.write_gate.weight.grad.norm().item(), 0.)
        self.assertLessEqual(max(metrics['frame_ratio']), .03 + 1e-6)

    def test_struct_trains_textinit_but_cannot_train_writers(self):
        _, adapter, geo = gated_fixture()
        text = torch.randn(1, 3, 4)
        h = [torch.randn(1, 4, 4, requires_grad=True) for _ in range(2)]
        mixer = GradientMixer(adapter.auxiliary_parameters(), adapter.parameters(), adapter.core_parameters())
        p0 = adapter.initialize(text, geo, 't2v')
        p15 = adapter.auxiliary(p0, h, text, torch.tensor(.5), 5., geo, detach_initial=False)
        mixer.accumulate_aux(.05 * (p15 - 1.).square().mean())
        metrics = mixer.combine(max_share=None)
        self.assertEqual(metrics['aux_alpha'], 1.)
        self.assertIsNone(metrics['core_generation_struct_cosine'])
        self.assertGreater(adapter.text_init.output[-1].weight.grad.norm().item(), 0.)
        self.assertTrue(all(v.grad is None for v in h))
        self.assertTrue(all(p.grad is None for c in adapter.correctors.values() for p in c.writer.parameters()))
        self.assertTrue(all(c.core.output[-1].weight.grad.norm() > 0 for c in adapter.correctors.values()))

    def test_uniform_sampler_and_checkpoint_resume(self):
        cfg, adapter, _ = gated_fixture()
        records = [dict(category='unlabeled') for _ in range(32)]
        plan = UniformExposurePlan(records, 42)
        first = plan.batch(1)
        self.assertEqual(len({e['index'] for e in first}), 8)
        self.assertTrue(all(not e['temporal'] and not e['repair'] for e in first))
        optimizer, ema = optimizer_for(adapter, cfg), EMA(adapter)
        set_schedule(adapter, optimizer, cfg, 1)
        sum(p.square().sum() for p in adapter.parameters()).backward()
        optimizer.step()
        ema.update(adapter)
        identity = dict(test='corrected_training')
        (ROOT / 'tmp').mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=ROOT / 'tmp') as directory:
            path = save_checkpoint(directory, 1, adapter, optimizer, ema, plan, cfg, identity)
            _, loaded, _ = gated_fixture()
            opt = optimizer_for(loaded, cfg)
            resumed = UniformExposurePlan(records, 42)
            step, restored_ema, _ = load_training(path, loaded, opt, resumed, cfg, identity)
            self.assertEqual(step, 1)
            self.assertEqual(restored_ema.updates, 1)
            self.assertEqual(resumed.batch(2), plan.batch(2))
            for name, value in loaded.state_dict().items():
                torch.testing.assert_close(value, adapter.state_dict()[name], rtol=0, atol=0)
            incompatible = copy.deepcopy(cfg)
            incompatible['train']['recipe'] = 'fm_joint_independent_cores_struct_global_share20_v2'
            with self.assertRaisesRegex(ValueError, 'different training recipe'):
                load_training(path, loaded, opt, resumed, incompatible, identity)
        for step in range(3, 1201):
            plan.batch(step)
        state = plan.state_dict()
        self.assertEqual(state['cursor'], 9600)
        t2v = sum(c['t2v'] for c in state['counts'])
        self.assertLess(abs(t2v / 9600 - .5), .03)

    def test_conflicting_component_only_and_unused_parameters(self):
        core = torch.nn.Linear(2, 1, bias=False)
        unused = torch.nn.Linear(1, 1, bias=False)
        params = list(core.parameters())+list(unused.parameters())
        mixer = GradientMixer(params, params, core.parameters())
        core.weight[0,0].backward()  # g_FM = [1, 0]
        mixer.accumulate_aux(-2*core.weight[0,0]+3*core.weight[0,1])  # g_STRUCT = [-2, 3]
        report = mixer.align_to_generation(dict(core=core, unused=unused))
        self.assertTrue(report['core']['conflict'])
        self.assertAlmostEqual(report['core']['removed_norm'], 2.)
        self.assertAlmostEqual(report['core']['dot_after'], 0.)
        mixer.combine(None)
        torch.testing.assert_close(core.weight.grad, torch.tensor([[1.,3.]]))
        self.assertIsNone(unused.weight.grad)  # No AdamW momentum/decay on absent modes.

    def test_ema_context_restores_raw_even_on_error(self):
        _, adapter, _ = gated_fixture()
        ema = EMA(adapter)
        with torch.no_grad():
            for p in adapter.parameters(): p.add_(1)
        original = {n:p.detach().clone() for n,p in adapter.named_parameters()}
        with self.assertRaisesRegex(RuntimeError, 'evaluation failed'):
            with ema.average_parameters(adapter):
                for n,p in adapter.named_parameters():
                    torch.testing.assert_close(p, ema.values[n], rtol=0, atol=0)
                raise RuntimeError('evaluation failed')
        for n,p in adapter.named_parameters():
            torch.testing.assert_close(p, original[n], rtol=0, atol=0)


if __name__ == '__main__':
    torch.set_num_threads(2)
    unittest.main()
