"""Actual small reader/writer graphs: joint gradients, GT isolation and resume."""
import copy
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(Path(__file__).resolve().parent))
import torch
from torch import nn
import torch.nn.functional as F
from test_independent_correctors import fixture
from physgen_v42.backbone import ProcessWan
from physgen_v42.data import UniformExposurePlan
from physgen_v42.geometry import Geometry
from physgen_v42.model import Adapter
from physgen_v42.optim import EMA, V4_JOINT_RECIPE, optimizer_for, set_schedule, save_checkpoint, load_training
from physgen_v42.runtime import read_config
from physgen_v42.training_log import loss_breakdown
from physgen_v42.v4_joint import state_supervision, train_micro_joint, gt_conditioned_step, gradient_diagnostics


def joint_fixture():
    cfg, old, geo = fixture()
    cfg['state'].update(initializer='condition_trajectory_gt_v1', prior_video_pool=8, write_gate=True)
    cfg['train'].update(recipe=V4_JOINT_RECIPE, ema_decay=.995)
    geo.geo = dict(h=32,w=64,frames=5)
    geo.v_weight = torch.ones(8)
    geo.position = lambda phase, xy, width: Geometry.position(geo,phase,xy,width)
    a = Adapter(cfg,{k:getattr(old,k) for k in ('mu_first','s_z','s_v')},hidden=4,text_dim=4,spatial=2)
    return cfg, a, geo


class Block(nn.Linear):
    def __init__(self): super().__init__(4,4)
    def forward(self,x,**kwargs): return x + .03*torch.tanh(super().forward(x))


class SmallProcess(ProcessWan):
    def __init__(self, adapter):
        wan = nn.Module()
        wan.blocks = nn.ModuleList([Block() for _ in range(30)])
        wan.input = nn.Linear(48,4)
        wan.output = nn.Linear(4,48)
        wan.requires_grad_(False)
        super().__init__(wan,adapter,recompute=False)

    def inputs(self,x,text,sigma,first):
        y = F.avg_pool3d(x,kernel_size=(1,2,2)).flatten(2).transpose(1,2)
        return self.wan.input(y), {}, None, (x.shape[2],x.shape[3]//2,x.shape[4]//2)

    def head(self,h,e,grid):
        t,y,x = grid
        v = self.wan.output(h).transpose(1,2).reshape(1,48,t,y,x)
        return v.repeat_interleave(2,-2).repeat_interleave(2,-1)


class JointTrainingTests(unittest.TestCase):
    def test_raw_multistate_average_and_time_preserving_prior(self):
        target = torch.zeros(1,2,2,4,requires_grad=True)
        states = {n:torch.full_like(target,v,requires_grad=True) for n,v in [('p0',1.),('p5',2.),('p15',4.)]}
        struct,prior,by_site = state_supervision(states,target,torch.tensor([1.,0.]))
        self.assertEqual(float(struct.detach()),10.)
        self.assertEqual(float(prior.detach()),1.)
        (struct+prior).backward()
        self.assertIsNone(target.grad)
        self.assertTrue(all(v.grad is not None for v in states.values()))
        temporal = torch.tensor([-1.,1.]).reshape(1,2,1,1).expand_as(target)
        states['p0'] = temporal
        self.assertEqual(float(state_supervision(states,target,torch.ones(2))[1].detach()),1.)

    def test_gt_all_times_training_only_and_no_gt_input_gradient(self):
        _,a,geo = joint_fixture()
        text = torch.randn(1,3,4)
        gt = torch.randn(1,48,2,2,4,requires_grad=True)
        seen=[]
        handle=a.text_init.video_norm.register_forward_pre_hook(lambda m,args:seen.append(args[0].shape))
        with torch.no_grad(): a.text_init.output[-1].weight.normal_(0,.1)
        before=a.initialize(text,geo,'t2v',gt_video=gt)
        changed=gt.detach().clone();changed[:,:,1]+=torch.randn(1,48,1,1)
        after=a.initialize(text,geo,'t2v',gt_video=changed)
        self.assertEqual(seen[0],(1,2,8,48))
        self.assertGreater(float((before-after).detach().abs().max()),1e-6)
        before.square().mean().backward()
        self.assertIsNone(gt.grad)
        self.assertGreater(float(a.text_init.video_proj.weight.grad.norm()),0.)
        handle.remove()
        a.eval()
        self.assertTrue(torch.isfinite(a.initialize(text,geo,'t2v')).all())
        with self.assertRaisesRegex(ValueError,'training mode'): a.initialize(text,geo,'t2v',gt_video=gt)
        _,old,_=fixture()
        with self.assertRaisesRegex(ValueError,'does not support'): old.initialize(text,geo,'t2v',gt_video=gt)

    def test_actual_struct_reaches_upstream_writer_and_both_cores(self):
        _,a,geo=joint_fixture(); model=SmallProcess(a)
        with torch.no_grad(): a.correctors['15'].core.output[-1].weight.normal_(0,.05)
        text=torch.randn(1,3,4); x=torch.randn(1,48,2,2,4)
        p0=a.initialize(text,geo,'t2v')
        r=model(x,None,text,torch.tensor(.5),5.,geo,p0,retain_state_graph=True)
        state_supervision(r,torch.randn_like(p0),geo.p_weight)[0].backward()
        self.assertGreater(float(a.correctors['5'].writer.output.weight.grad.norm()),0.)
        self.assertTrue(all(a.correctors[s].core.output[-1].weight.grad.norm()>0 for s in ['5','15']))
        self.assertTrue(all(p.grad is None for p in a.correctors['15'].writer.parameters()))
        self.assertTrue(all(p.grad is None for p in model.wan.parameters()))

    def test_joint_micro_keeps_write_and_exact_loss_accounting(self):
        cfg,a,geo=joint_fixture();model=SmallProcess(a)
        weights=dict(fm=1.,struct=.1,prior=.02,write=.05,temp=0.,struct_warmup_steps=200,struct_noise_width=.2)
        sample=dict(latent=torch.randn(1,48,2,2,4),first=None,text=torch.randn(1,3,4),
                    anchor=None,target=torch.randn(1,2,2,4),record=dict(geometry=geo.geo,duration=1.))
        with patch('physgen_v42.v4_joint.Geometry.build',return_value=geo):
            m=train_micro_joint(model,sample,dict(mode='t2v'),100,8,weights,gt_conditioned=True,
                empty_text=torch.zeros(1,1,4),text_dropout=1.,
                repair=dict(clean_probability=0.,max_relative_strength=.2,warp_latent_pixels=.5),
                diagnose_gradients=True)
        self.assertTrue(m['gt_conditioned'] and m['text_dropped'])
        self.assertGreater(m['write'],0.)
        self.assertEqual(m['prior_coefficient'],.01)
        self.assertEqual(m['gradient_diagnostics']['scope'],'first_micro_before_backward')
        logs=loss_breakdown([m]*8,weights,1.)
        self.assertAlmostEqual(logs['loss_total'],8*sum(m['weighted_'+k] for k in ['fm','struct','prior','write']))
        self.assertGreater(float(a.text_init.output[-1].weight.grad.norm()),0.)
        self.assertTrue(all(a.correctors[s].writer.output.weight.grad.norm()>0 for s in ['5','15']))

    def test_conflicts_are_recorded_without_changing_gradient(self):
        class Toy(nn.Linear):
            def groups(self): return dict(shared=self)
        a=Toy(2,1,bias=False)
        fm=a.weight[0,0]; aux=-2*a.weight[0,0]+3*a.weight[0,1]
        report=gradient_diagnostics(fm,aux,a)
        self.assertTrue(report['groups']['shared']['conflict'])
        self.assertIsNone(a.weight.grad)
        (fm+aux).backward()
        torch.testing.assert_close(a.weight.grad,torch.tensor([[-1.,3.]]))

    def test_new_config_and_resume_preserve_gt_random_choice(self):
        full=read_config(ROOT/'configs/stability_v4_joint.yaml')
        self.assertEqual(full['train']['auxiliary_gradient_policy'],'none')
        self.assertEqual(full['loss']['prior'],.02)
        cfg,a,_=joint_fixture()
        opt=optimizer_for(a,cfg); set_schedule(a,opt,cfg,1)
        plan=UniformExposurePlan([dict(id=str(i),category='test') for i in range(16)],11); plan.batch(1)
        ema=EMA(a);ema.update(a)
        identity={k:'test' for k in ['manifest','statistics','assets','code']}
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as tmp:
            p=save_checkpoint(tmp,1,a,opt,ema,plan,cfg,identity)
            expected=[gt_conditioned_step(.25,torch.device('cpu')) for _ in range(30)]
            _,b,_=joint_fixture(); resumed=UniformExposurePlan(plan.records,11)
            step,_,rng=load_training(p,b,optimizer_for(b,cfg),resumed,cfg,identity)
            from physgen_v42.optim import restore_rng
            restore_rng(rng)
            self.assertEqual(expected,[gt_conditioned_step(.25,torch.device('cpu')) for _ in range(30)])
            self.assertEqual(step,1)
            for n,v in a.state_dict().items(): torch.testing.assert_close(v,b.state_dict()[n],rtol=0,atol=0)


if __name__=='__main__':
    torch.set_num_threads(2)
    unittest.main()
