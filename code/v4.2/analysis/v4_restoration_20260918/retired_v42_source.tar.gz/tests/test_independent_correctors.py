"""Actual small correctors: parameter isolation, zero-writer startup and gradient routing."""
import copy
import io
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch

from physgen_v42.model import Adapter
from physgen_v42.optim import GradientMixer, optimizer_for


def fixture():
    torch.manual_seed(91)
    cfg = dict(state=dict(sites=[5, 15], width=4, inner=4, heads=1, depth=1, checkpoint=False),
               train=dict(peak_lr={name: 1e-3 for name in ("core5", "core15", "text_init", "writer5", "writer15")}))
    adapter = Adapter(cfg, dict(mu_first=torch.randn(2, 4), s_z=1., s_v=1.), hidden=4, text_dim=4, spatial=2)
    geo = SimpleNamespace(h_phase=torch.tensor([0., 1.]), p_phase=torch.tensor([0., 1.]),
                          h_weight=torch.ones(2), p_weight=torch.ones(2), h_xy=torch.zeros(2, 2),
                          p_xy=torch.zeros(2, 2), position=lambda *args: torch.zeros(1, 2, 2, 4))
    return cfg, adapter, geo


class IndependentCorrectorTests(unittest.TestCase):
    def test_independent_modules_optimizer_moments_and_checkpoint(self):
        cfg, adapter, _ = fixture()
        a, b = adapter.correctors["5"], adapter.correctors["15"]
        self.assertIsNot(a.reader, b.reader)
        self.assertIsNot(a.core, b.core)
        self.assertIsNot(a.writer, b.writer)
        self.assertFalse({p.data_ptr() for p in a.parameters()} & {p.data_ptr() for p in b.parameters()})
        optimizer = optimizer_for(adapter, cfg)
        ids = [id(p) for g in optimizer.param_groups for p in g["params"]]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(set(ids), {id(p) for p in adapter.parameters()})
        self.assertEqual(set(adapter.groups()), set(cfg["train"]["peak_lr"]))
        before_b = copy.deepcopy(b.state_dict())
        # Updating only site 5 must leave every site 15 parameter unchanged.
        sum((p - 1).square().sum() for p in a.parameters()).backward()
        optimizer.step()
        for name, value in b.state_dict().items():
            torch.testing.assert_close(value, before_b[name], rtol=0, atol=0)
        self.assertTrue(all(p not in optimizer.state for p in b.parameters()))
        optimizer.zero_grad(set_to_none=True)
        sum((p + 1).square().sum() for p in b.parameters()).backward()
        optimizer.step()
        for pa, pb in zip(a.parameters(), b.parameters()):
            self.assertNotEqual(optimizer.state[pa]["exp_avg"].data_ptr(), optimizer.state[pb]["exp_avg"].data_ptr())
        buffer = io.BytesIO()
        torch.save(adapter.state_dict(), buffer)
        buffer.seek(0)
        _, restored, _ = fixture()
        restored.load_state_dict(torch.load(buffer, weights_only=True), strict=True)
        for name, value in adapter.state_dict().items():
            torch.testing.assert_close(restored.state_dict()[name], value, rtol=0, atol=0)

    def test_struct_reaches_both_cores_when_writers_are_zero(self):
        _, adapter, geo = fixture()
        a, b = adapter.correctors["5"], adapter.correctors["15"]
        mixer = GradientMixer(adapter.core_parameters(), adapter.parameters())
        text, sigma = torch.randn(1, 3, 4), torch.tensor(.1)
        h5 = torch.randn(1, 4, 4)
        p0 = adapter.initialize(text, geo, "t2v")
        p5 = a.core(p0, h5, text, sigma, 5., 0, geo, adapter.s_z)
        out5, _ = a.writer(h5, p5, h5, sigma, 1., False, 5, geo)
        h15, base15 = out5 * 1.1 + .2, h5 * 1.1 + .2
        p15 = b.core(p5, h15, text, sigma, 5., 1, geo, adapter.s_z)
        out15, _ = b.writer(h15, p15, base15, sigma, 1., False, 15, geo)
        torch.testing.assert_close(out15, base15, rtol=0, atol=0)
        (out15 - 1.).square().mean().backward()
        self.assertTrue(all(p.grad is None or not torch.count_nonzero(p.grad) for p in adapter.core_parameters()))
        noncore = {n: None if p.grad is None else p.grad.clone() for n, p in adapter.named_parameters()
                   if ".core." not in n}
        aux = adapter.auxiliary(p0, (h5, h15), text, sigma, 5., geo)
        mixer.accumulate_aux(.1 * (aux - 1000).square().mean())
        result = mixer.combine(max_share=.2)
        self.assertEqual(result["core_generation_grad"], 0.)
        self.assertGreater(result["generation_grad_all"], 0.)
        self.assertGreater(result["effective_aux_grad"], 0.)
        self.assertAlmostEqual(result["aux_grad_share"], .2, places=6)
        self.assertAlmostEqual(result["effective_aux_grad"], .25 * result["generation_grad_all"], places=6)
        for core in (a.core, b.core):
            self.assertGreater(core.output[-1].weight.grad.abs().sum().item(), 0.)
        for name, param in adapter.named_parameters():
            if name in noncore:
                if noncore[name] is None:
                    self.assertIsNone(param.grad)
                else:
                    torch.testing.assert_close(param.grad, noncore[name], rtol=0, atol=0)

    def test_auxiliary_inputs_detached_and_weak_aux_not_amplified(self):
        _, adapter, geo = fixture()
        text = torch.randn(1, 3, 4, requires_grad=True)
        p0 = adapter.initialize(text, geo, "t2v")
        observations = [torch.randn(1, 4, 4, requires_grad=True) for _ in range(2)]
        aux = adapter.auxiliary(p0, observations, text, torch.tensor(.1), 5., geo)
        (aux - 1).square().mean().backward()
        self.assertIsNone(text.grad)
        self.assertTrue(all(h.grad is None for h in observations))
        self.assertTrue(all(p.grad is None for p in adapter.text_init.parameters()))
        self.assertTrue(all(p.grad is None for c in adapter.correctors.values() for p in c.writer.parameters()))
        p, w = torch.nn.Parameter(torch.ones(1)), torch.nn.Parameter(torch.ones(1))
        mixer = GradientMixer([p], [p, w])
        (p + 10 * w).sum().backward()
        mixer.accumulate_aux(.001 * p.sum())
        result = mixer.combine(.2)
        self.assertEqual(result["aux_alpha"], 1.)
        self.assertLess(result["aux_grad_share"], .2)
        torch.testing.assert_close(p.grad, torch.tensor([1.001]))


if __name__ == "__main__":
    torch.set_num_threads(2)
    unittest.main()
