"""Regression checks for the conditional-model mismatch in legacy generation."""
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch
from inference.infer import corrected_cfg, inference_recipe, sampling_schedule, build_plan, read_config


class InferenceCFGTests(unittest.TestCase):
    def test_guidance_uses_both_learned_predictions(self):
        base_positive, base_negative = torch.tensor([2.]), torch.tensor([1.])
        delta_positive, delta_negative = torch.tensor([.3]), torch.tensor([-.2])
        actual = corrected_cfg(base_positive + delta_positive, base_negative + delta_negative, 5)
        expected = base_negative + 5*(base_positive-base_negative) + 5*delta_positive - 4*delta_negative
        torch.testing.assert_close(actual, expected)
        self.assertFalse(torch.allclose(actual, base_negative+5*(base_positive-base_negative)+delta_positive))

    def test_guidance_one_is_exact_training_prediction(self):
        positive, negative = torch.randn(4), torch.randn(4)
        torch.testing.assert_close(corrected_cfg(positive, negative, 1), positive)
        torch.testing.assert_close(corrected_cfg(positive, negative, 0), negative)

    def test_profile_rejects_untrained_empty_branch(self):
        with self.assertRaises(ValueError):
            inference_recipe({'train': {}}, 'v4_matched')

    def test_euler_integrates_constant_velocity_to_zero_sigma(self):
        recipe = inference_recipe({'train': {'text_dropout': .1}}, 'v4_matched')
        sampler, times, sigmas = sampling_schedule(recipe, torch.device('cpu'))
        self.assertIsNone(sampler)
        self.assertEqual(len(times), 50)
        self.assertEqual(float(sigmas[0]), 1.)
        self.assertEqual(float(sigmas[-1]), 0.)
        x = torch.tensor(3.)
        for index in range(len(times)):
            x += (sigmas[index+1]-sigmas[index])*2
        torch.testing.assert_close(x, torch.tensor(1.))

    def test_original_plan_is_reproduced_for_existing_output(self):
        import json
        root = Path(__file__).resolve().parents[1]
        folder = root/'inference_outputs/v4_joint_20260918T034836Z_16183b_step0400_ema_demo_seed42_r3_full'
        saved = json.loads((folder/'cases.json').read_text())
        args = SimpleNamespace(checkpoint=saved['checkpoint'], suite='demo', portrait=False,
                               duration=5., variant='full', profile='legacy_r3', weights='ema', case_keys=None)
        cfg = read_config(Path(saved['checkpoint'])/'config.json')
        self.assertEqual(build_plan(cfg,args), saved)


if __name__ == '__main__':
    unittest.main()
