"""CPU cache integration: partial reuse, corruption repair and subset preservation."""
import copy
from contextlib import nullcontext, redirect_stdout
import io
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch

from physgen_v42 import VERSION
from physgen_v42.cache import (CacheStore, LEGACY_PREPARATION, compatible_preparation,
                               ready_valid, validate)
from physgen_v42.geometry import fit_geometry
from physgen_v42.runtime import (ROOT, digest, file_identity, preparation_fingerprint,
                                read_json, save_json, save_tensor, sha256)
from tools import bootstrap, dataset_index, prepare


class CacheReuseTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(dir=ROOT / "tmp")
        self.addCleanup(self.directory.cleanup)
        base = Path(self.directory.name)
        self.root, self.source = base / "new", base / "source"
        self.root.mkdir()
        self.source.mkdir()
        self.cfg = dict(paths=dict(cache=str(self.root), annotations=str(base / "index")),
                        preparation=dict(reuse_sources=[str(self.source)]),
                        data=dict(limit=2, source_limit=4, seed=42, validation_stride=20, frames=121,
                                  max_long_side=512, max_area=147456, decode_chunk_frames=8,
                                  teacher_frames=32, teacher_size=384, categories=["unlabeled"]))
        self.records = [dict(id=f"source{i:07d}", source_id=f"{i:064x}", video=str(base / f"{i}.mp4"),
                             source_file=dict(bytes=100, mtime_ns=123), split="train" if i % 2 == 0 else "validation",
                             caption=f"caption {i}", category="unlabeled", indices=list(range(5)),
                             pts=[0., .04, .08, .12, .16], duration=.16, source_frames=5,
                             geometry=dict(fit_geometry(32, 32, 32, 32, upscale=False), frames=5), interactions=[])
                        for i in range(4)]
        self.manifest = dict(version=VERSION, data_config=self.cfg["data"], records=self.records[:2],
                             source_counts=dict(train=1, validation=1), assets={}, negative_prompt="negative",
                             preparation_code=preparation_fingerprint())
        save_json(self.manifest, self.root / "manifest.json")
        source = dict(self.manifest, records=self.records, preparation_code=LEGACY_PREPARATION)
        save_json(source, self.source / "manifest.json")
        self.capture = redirect_stdout(io.StringIO())
        self.capture.__enter__()
        self.addCleanup(self.capture.__exit__, None, None, None)

    @staticmethod
    def value(stage):
        if stage == "vae":
            return dict(latent=torch.ones(1, 48, 2, 2, 2), first=torch.ones(1, 48, 1, 2, 2))
        shape = {"text": (2, 4096), "teacher": (1, 16, 576, 1664), "anchors": (1, 576, 1664)}[stage]
        return torch.ones(shape, dtype=torch.bfloat16)

    def save(self, root, stage, record=None):
        record = record or self.records[0]
        path = root / stage / (record["id"] + ".pt")
        save_tensor(self.value(stage), path)
        return path

    def test_source_hardlink_receipt_and_corrupt_local_repair(self):
        original = self.save(self.source, "vae")
        store = CacheStore(self.cfg, self.manifest)
        self.assertEqual(store.ensure("vae", self.records[0]), "reused")
        local = self.root / "vae" / original.name
        self.assertEqual(local.stat().st_ino, original.stat().st_ino)
        store.save()
        with patch("torch.load", side_effect=AssertionError("Validated cache should only need metadata")):
            self.assertEqual(CacheStore(self.cfg, self.manifest).ensure("vae", self.records[0]), "local")
        # Replace the local file atomically, so corruption cannot affect the source hardlink.
        bad = self.value("vae")
        bad["latent"][0, 0, 0, 0, 0] = float("nan")
        save_tensor(bad, local)
        self.assertEqual(store.ensure("vae", self.records[0]), "reused")
        validate("vae", torch.load(original, weights_only=True), self.records[0])
        self.assertEqual(store.ensure("vae", self.records[1]), "missing")

    def test_all_vae_cached_skips_gpu_encoder_and_video_decode(self):
        for record in self.records[:2]:
            self.save(self.source, "vae", record)
        with patch.object(prepare, "lock_assets", return_value={}), \
                patch.object(prepare, "require_single_gpu", side_effect=AssertionError("No GPU needed")), \
                patch("physgen_v42.encoders.load_vae", side_effect=AssertionError("No VAE load needed")), \
                patch("physgen_v42.data.read_window", side_effect=AssertionError("No source decode needed")):
            prepare.encode(self.cfg, "vae")

    def test_missing_anchor_does_not_reencode_existing_teacher(self):
        # One record suffices here; this tests stage encoding, not split validation.
        self.manifest["records"] = self.records[:1]
        save_json(self.manifest, self.root / "manifest.json")
        teacher_path = self.save(self.root, "teacher")
        before = file_identity(teacher_path)
        calls = []
        def teacher(video, first_image=False):
            calls.append(first_image)
            self.assertTrue(first_image, "Existing full-video JEPA features must be reused")
            return self.value("anchors")
        with patch.object(prepare, "lock_assets", return_value={}), \
                patch.object(prepare, "source_identity", return_value=self.records[0]["source_file"]), \
                patch.object(prepare, "require_single_gpu", return_value=torch.device("cpu")), \
                patch("physgen_v42.encoders.VideoTeacher", return_value=teacher), \
                patch("physgen_v42.data.read_window", return_value=torch.ones(1, 3, 5, 32, 32)):
            prepare.encode(self.cfg, "teacher")
        self.assertEqual(calls, [True])
        self.assertEqual(file_identity(teacher_path), before)
        self.assertTrue((self.root / "anchors" / teacher_path.name).exists())

    def test_corrupt_negative_is_regenerated_without_positive_text_encoding(self):
        self.manifest["records"] = self.records[:1]
        save_json(self.manifest, self.root / "manifest.json")
        self.save(self.root, "text")
        (self.root / "negative.pt").write_bytes(b"broken")
        calls = []
        def text(prompts, device):
            calls.append(prompts)
            return [self.value("text")]
        with patch.object(prepare, "lock_assets", return_value={}), \
                patch.object(prepare, "require_single_gpu", return_value=torch.device("cpu")), \
                patch("physgen_v42.encoders.load_text", return_value=text), \
                patch("torch.autocast", side_effect=lambda *args, **kwargs: nullcontext()):
            prepare.encode(self.cfg, "text")
        self.assertEqual(calls, [["negative"]])
        validate("text", torch.load(self.root / "negative.pt", weights_only=True), self.records[0])

    def test_changed_caption_reuses_vae_but_rejects_stale_text(self):
        self.save(self.source, "text")
        self.save(self.source, "vae")
        changed = copy.deepcopy(self.manifest)
        changed["records"][0]["caption"] = "changed prompt"
        store = CacheStore(self.cfg, changed)
        self.assertEqual(store.ensure("text", changed["records"][0]), "missing")
        self.assertEqual(store.ensure("vae", changed["records"][0]), "reused")

    def test_subset_keeps_source_order_and_split_without_decoding(self):
        (self.root / "manifest.json").unlink()
        self.cfg["data"]["subset_manifest"] = str(self.source / "manifest.json")
        with patch.object(dataset_index, "lock_assets", return_value={}), \
                patch.object(dataset_index, "native_negative", return_value="negative"):
            dataset_index.index(self.cfg)
        manifest = read_json(self.root / "manifest.json")
        self.assertEqual(manifest["records"], self.records[:2])
        self.assertEqual(manifest["source_counts"], dict(train=1, validation=1))
        self.assertEqual(manifest["preparation_code"], preparation_fingerprint())
        # Index is idempotent, and the four-record source remains untouched.
        before = (self.root / "manifest.json").read_bytes()
        with patch.object(dataset_index, "lock_assets", return_value={}):
            dataset_index.index(self.cfg)
        self.assertEqual(before, (self.root / "manifest.json").read_bytes())
        self.assertEqual(len(read_json(self.source / "manifest.json")["records"]), 4)

    def test_legacy_allowlist_rejects_unreviewed_encoding_code(self):
        self.assertTrue(compatible_preparation(LEGACY_PREPARATION))
        changed = dict(LEGACY_PREPARATION, **{"tools/prepare.py": "changed"})
        self.assertFalse(compatible_preparation(changed))
        source = read_json(self.source / "manifest.json")
        source["preparation_code"] = changed
        save_json(source, self.source / "manifest.json")
        self.save(self.source, "vae")
        self.assertEqual(CacheStore(self.cfg, self.manifest).ensure("vae", self.records[0]), "missing")

    def test_broken_ready_reenters_repair_on_resume(self):
        save_json(dict(manifest_hash=digest(self.manifest), files={}, statistics_sha256="missing"), self.root / "ready.json")
        self.assertFalse(ready_valid(self.cfg))
        with patch.object(bootstrap, "run_role") as run:
            bootstrap.ensure_data(self.cfg, "config.yaml", resume=True)
        self.assertEqual([call.args[-1] for call in run.call_args_list], ["index", "vae", "text", "teacher", "finalize"])
        with patch.object(bootstrap, "ready_valid", return_value=True), patch.object(bootstrap, "run_role") as run:
            bootstrap.ensure_data(self.cfg, "config.yaml")
        self.assertEqual([call.args[-1] for call in run.call_args_list], ["index"])

    def test_ready_requires_every_record_component(self):
        save_tensor({}, self.root / "stats.pt")
        files = {}
        # Placeholder bytes are sufficient: ready_valid checks finalized file identities.
        for record in self.manifest["records"]:
            for stage in ("vae", "text", "teacher", "anchors"):
                path = self.root / stage / (record["id"] + ".pt")
                path.parent.mkdir(exist_ok=True)
                path.write_bytes(b"finalized")
                files[str(path.relative_to(self.root))] = file_identity(path)
        (self.root / "negative.pt").write_bytes(b"negative")
        files["negative.pt"] = file_identity(self.root / "negative.pt")
        ready = dict(manifest_hash=digest(self.manifest), files=files, statistics_sha256=sha256(self.root / "stats.pt"))
        save_json(ready, self.root / "ready.json")
        self.assertTrue(ready_valid(self.cfg))
        (self.root / "anchors" / (self.records[0]["id"] + ".pt")).unlink()
        self.assertFalse(ready_valid(self.cfg))

    def test_identical_repair_preserves_resume_statistics_identity(self):
        for record in self.manifest["records"]:
            for stage in ("vae", "text", "teacher", "anchors"):
                self.save(self.root, stage, record)
        save_tensor(self.value("text"), self.root / "negative.pt")
        with patch.object(prepare, "lock_assets", return_value={}):
            prepare.finalize(self.cfg)
            self.assertTrue(ready_valid(self.cfg))
            old = file_identity(self.root / "stats.pt")
            # Repair with identical tensors but a different file identity.
            self.save(self.root, "vae")
            self.assertFalse(ready_valid(self.cfg))
            prepare.finalize(self.cfg)
            self.assertEqual(file_identity(self.root / "stats.pt"), old)
            self.assertTrue(ready_valid(self.cfg))
            # Changed calibration data must not reuse the old statistics.
            changed = self.value("vae")
            changed["latent"] += 1
            save_tensor(changed, self.root / "vae" / (self.records[0]["id"] + ".pt"))
            prepare.finalize(self.cfg)
            self.assertNotEqual(sha256(self.root / "stats.pt"), old["sha256"])


if __name__ == "__main__":
    torch.set_num_threads(2)
    unittest.main()
