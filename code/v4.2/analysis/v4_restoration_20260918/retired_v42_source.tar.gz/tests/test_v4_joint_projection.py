"""Paired ablation checks: same forward/RNG/gradients, then group projection."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(Path(__file__).resolve().parent)]
import torch
import yaml
from test_v4_joint import joint_fixture, SmallProcess
from physgen_v42.optim import EMA, optimizer_for, set_schedule, save_checkpoint, load_training
from physgen_v42.data import UniformExposurePlan
from physgen_v42.runtime import read_config
from physgen_v42.v4_joint import train_micro_joint, JointConflictProjector


class JointProjectionTests(unittest.TestCase):
    def test_only_training_policy_differs_and_launch_selects_it(self):
        a=read_config(ROOT/'configs/stability_v4_joint.yaml')
        b=read_config(ROOT/'configs/stability_v4_joint_projected.yaml')
        self.assertEqual(a['train']['auxiliary_gradient_policy'],'none')
        self.assertEqual(b['train']['auxiliary_gradient_policy'],'project_conflicts')
        b['train']['auxiliary_gradient_policy']='none'
        self.assertEqual(a,b)
        base=yaml.safe_load((ROOT/'train/train_stability_1x96g.yaml').read_text())
        extra=yaml.safe_load((ROOT/'train/train_stability_projected_1x96g.yaml').read_text())
        self.assertNotEqual(base.pop('name'),extra.pop('name'))
        base.pop('description');extra.pop('description')
        env=extra['environment']['environment_variables']
        self.assertIn('CONFIG='+str(ROOT/'configs/stability_v4_joint_projected.yaml'),env)
        extra['environment']['environment_variables']=[x.replace('stability_v4_joint_projected.yaml','stability_v4_joint.yaml') for x in env]
        self.assertEqual(base,extra)

    def test_eight_micro_forward_rng_and_unprojected_gradient_equivalence(self):
        _,a,geo=joint_fixture();model=SmallProcess(a)
        with torch.no_grad():
            for site in ('5','15'):
                a.correctors[site].core.output[-1].weight.normal_(0,.03)
                a.correctors[site].writer.output.weight.normal_(0,.02)
            a.text_init.output[-1].weight.normal_(0,.02)
        other=copy.deepcopy(model)
        sample=dict(latent=torch.randn(1,48,2,2,4),first=None,text=torch.randn(1,3,4),
                    anchor=None,target=torch.randn(1,2,2,4),record=dict(geometry=geo.geo,duration=1.))
        weights=dict(fm=1.,struct=.1,prior=.02,write=.05,temp=0.,struct_warmup_steps=200,struct_noise_width=.2)
        options=dict(gt_conditioned=True,empty_text=torch.zeros(1,1,4),text_dropout=.1,
                     repair=dict(clean_probability=.25,max_relative_strength=.2,warp_latent_pixels=.5))
        rng=torch.get_rng_state()
        with patch('physgen_v42.v4_joint.Geometry.build',return_value=geo):
            rows=[train_micro_joint(model,sample,dict(mode='t2v'),300,8,weights,**options) for _ in range(8)]
            after=torch.get_rng_state()
            torch.set_rng_state(rng)
            b=other.adapter
            mixer=JointConflictProjector(b)
            paired=[train_micro_joint(other,sample,dict(mode='t2v'),300,8,weights,
                                     gradient_mixer=mixer,**options) for _ in range(8)]
        torch.testing.assert_close(after,torch.get_rng_state(),rtol=0,atol=0)
        self.assertEqual(rows,paired)
        gf=[g.clone() for g in mixer.fm]
        joint=[None if p.grad is None else p.grad.clone() for p in mixer.params]
        ga=[torch.zeros_like(f) if g is None else g-f for f,g in zip(gf,joint)]
        for p,q in zip(a.parameters(),b.parameters()):
            self.assertEqual(p.grad is None,q.grad is None)
            if p.grad is not None: torch.testing.assert_close(p.grad,q.grad,rtol=0,atol=0)
        lookup={id(p):i for i,p in enumerate(mixer.params)}
        expected={}
        for name,group in b.groups().items():
            ids=[lookup[id(p)] for p in group.parameters()]
            f2=sum(float(gf[i].square().sum()) for i in ids if gf[i] is not None)
            dot=sum(float((gf[i]*ga[i]).sum()) for i in ids if gf[i] is not None)
            projection=min(dot,0.)/f2 if f2>0 else 0.
            for i in ids:
                expected[i]=None if joint[i] is None else joint[i]-projection*gf[i]
        report=mixer.align_to_generation(b.groups())
        for i,p in enumerate(mixer.params):
            if p.grad is not None: torch.testing.assert_close(p.grad,expected[i],rtol=2e-5,atol=2e-7)
        for row in report.values():
            self.assertGreaterEqual(row['dot_after'],-1e-8)

    def test_conflicting_component_removed_and_zero_fm_preserved(self):
        for fm_scale,expected in [(1.,[1.,3.]),(0.,[-2.,3.])]:
            layer=torch.nn.Linear(2,1,bias=False)
            mixer=JointConflictProjector(layer)
            fm=fm_scale*layer.weight[0,0]
            aux=-2*layer.weight[0,0]+3*layer.weight[0,1]
            mixer.accumulate_fm(fm);(fm+aux).backward()
            report=mixer.align_to_generation(dict(shared=layer))['shared']
            self.assertEqual(report['conflict'],fm_scale>0)
            torch.testing.assert_close(layer.weight.grad,torch.tensor([expected]),rtol=0,atol=0)
            self.assertAlmostEqual(report['dot_after'],0.)

    def test_projection_happens_after_accumulation_not_per_micro(self):
        layer=torch.nn.Linear(2,1,bias=False)
        mixer=JointConflictProjector(layer)
        fm=layer.weight[0,0];aux=-2*layer.weight[0,0]+2*layer.weight[0,1]
        mixer.accumulate_fm(fm);(fm+aux).backward()
        fm=layer.weight[0,1];aux=2*layer.weight[0,0]-layer.weight[0,1]
        mixer.accumulate_fm(fm);(fm+aux).backward()
        report=mixer.align_to_generation(dict(shared=layer))
        self.assertFalse(report['shared']['conflict'])
        torch.testing.assert_close(layer.weight.grad,torch.tensor([[1.,2.]]))

    def test_resume_rejects_switching_projection_policy(self):
        cfg,a,_=joint_fixture();cfg['train']['auxiliary_gradient_policy']='project_conflicts'
        opt=optimizer_for(a,cfg);set_schedule(a,opt,cfg,1)
        plan=UniformExposurePlan([dict(id=str(i),category='test') for i in range(16)],11);plan.batch(1)
        ema=EMA(a);ema.update(a);identity={k:'test' for k in ['manifest','statistics','assets','code']}
        with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as tmp:
            saved=save_checkpoint(tmp,1,a,opt,ema,plan,cfg,identity)
            switched=copy.deepcopy(cfg);switched['train']['auxiliary_gradient_policy']='none'
            with self.assertRaisesRegex(ValueError,'changed training recipe'):
                load_training(saved,a,opt,plan,switched,identity)
            step,_,_=load_training(saved,a,opt,plan,cfg,identity)
            self.assertEqual(step,1)


if __name__=='__main__':
    torch.set_num_threads(2)
    unittest.main()
