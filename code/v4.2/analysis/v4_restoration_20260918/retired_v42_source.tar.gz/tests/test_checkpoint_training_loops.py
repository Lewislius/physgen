"""CPU checkpoint regression through the actual four production training loops.

Tiny differentiable models replace Wan/VAE and CUDA reporting. The optimizer,
EMA, exposure queues, loop, JSONL logging, checkpoint I/O and resume are real.
Run each loop through 1200, then resume its legacy-code step100 in a fresh run
directory and require bit-identical final weights and complete training state.
"""
from contextlib import ExitStack, redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import random
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
LORA_ROOT = ROOT.parent / "v4-static-lora"
sys.path[:0] = [str(ROOT), str(LORA_ROOT)]
import numpy as np
import torch

from physgen_v42 import runtime
from train import train as v42_training
from batch1 import train as batch1_training
from batch1.config import configuration as batch1_config
from static_lora import runtime as lora_runtime
from static_lora.config import configuration as lora_config
from static_lora.lora import LoRALinear, lora_named_parameters
from four_gpu.config import configuration as four_config
from four_gpu.runtime import log as four_log
from four_gpu.train import implementation as four_training


def lora_training():
    spec = importlib.util.spec_from_file_location("checkpoint_loop_lora", LORA_ROOT / "train/train.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TinyAdapter(torch.nn.Module):
    def __init__(self, *args):
        super().__init__()
        for name in ("core5", "core15", "text_init", "writer5", "writer15"):
            setattr(self, name, torch.nn.Linear(1, 1, bias=False))

    def groups(self):
        return {name: getattr(self, name) for name in ("core5", "core15", "text_init", "writer5", "writer15")}

    def core_parameters(self):
        yield from self.core5.parameters()
        yield from self.core15.parameters()


class TinyLoRA(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.layer = LoRALinear(torch.nn.Linear(2, 2), 1, 1)
        self.targets = ["layer"]


class TinyDataset:
    def __init__(self, cfg=None, split=None, **kwargs):
        self.records = [dict(id=f"sample{i}", category="unlabeled", duration=1.) for i in range(17)]
        self.manifest = dict(assets={}, records=self.records, health_ids=[])

    def __len__(self):
        return len(self.records)

    def load(self, index, mode, device):
        return dict(record=self.records[index])


def target():
    # Exercise restoration of all three CPU RNGs, after model construction.
    return torch.rand(()) + random.random() + np.random.rand()


def adapter_micro(model, decoder, sample, exposure, step, mixer, negative,
                  accumulation=8, loss_weights=None):
    weights = loss_weights
    a = model.adapter
    fm = sum((p - target()).square().sum() for p in a.parameters())
    (weights["fm"] * fm / accumulation).backward()
    struct = sum((p - target()).square().sum() for p in a.core_parameters())
    auxiliary = weights["struct"] * struct / accumulation
    mixer.accumulate_aux(auxiliary)
    return dict(fm=float(fm.detach()), struct=float(struct.detach()), temp=0.,
                weighted_fm=weights["fm"] * float(fm.detach()) / accumulation,
                weighted_struct=float(auxiliary.detach()), weighted_temp=0.,
                sigma=.4, temporal_sigma=.4, struct_noise_weight=1.,
                fm_active=True, temporal_active=exposure["temporal"], repair=exposure["repair"])


def batch1_micro(model, decoder, sample, exposure, step, mixer, negative, weights):
    return adapter_micro(model, decoder, sample, exposure, step, mixer, negative, 1, weights)


def lora_micro(model, sample, exposure, cfg):
    loss = sum((p - target()).square().sum() for _, p in lora_named_parameters(model))
    weighted = loss / cfg["train"]["accumulation"]
    weighted.backward()
    return dict(fm=float(loss.detach()), weighted_fm=float(weighted.detach()), sigma=.4,
                low_noise=exposure["low_noise"], fm_active=True, repair=False)


def jsonlines(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


class CheckpointLoopTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)
        cls.transitions = {row["profile"]: row for row in runtime.read_json(
            ROOT / "physgen_v42/checkpoint_compatibility.json")["transitions"]}

    def assert_state_equal(self, a, b):
        if isinstance(a, torch.Tensor):
            torch.testing.assert_close(a, b, rtol=0, atol=0)
        elif isinstance(a, np.ndarray):
            np.testing.assert_array_equal(a, b)
        elif isinstance(a, dict):
            self.assertEqual(a.keys(), b.keys())
            for key in a:
                self.assert_state_equal(a[key], b[key])
        elif isinstance(a, (list, tuple)):
            self.assertEqual(len(a), len(b))
            for x, y in zip(a, b):
                self.assert_state_equal(x, y)
        else:
            self.assertEqual(a, b)

    def test_all_loggers_accept_checkpoint_path_with_destination(self):
        for root, logger in ((ROOT, runtime.log), (LORA_ROOT, lora_runtime.log), (LORA_ROOT, four_log)):
            with self.subTest(logger=logger.__module__), tempfile.TemporaryDirectory(dir=root / "tmp") as tmp:
                destination = Path(tmp) / "events.jsonl"
                payload = dict(event="checkpoint", path=str(Path(tmp) / "step0100"), step=100)
                stream = io.StringIO()
                with redirect_stdout(stream):
                    logger(destination, console=False, **payload)
                self.assertEqual(stream.getvalue(), "")
                self.assertEqual(jsonlines(destination), [payload])
                with redirect_stdout(stream):
                    logger(**payload)
                self.assertEqual(json.loads(stream.getvalue()), payload)

    def test_code_compatibility_is_exact_and_preserves_every_other_identity_field(self):
        from batch1.config import code_fingerprint as batch_fingerprint
        from four_gpu.config import code_fingerprint as four_fingerprint
        from quick16.run import implementation_identity
        current = dict(v42=runtime.digest(runtime.code_fingerprint()),
                       batch1=runtime.digest(batch_fingerprint()),
                       lora=runtime.digest(lora_runtime.code_fingerprint()),
                       four_gpu=runtime.digest(four_fingerprint()), quick16=implementation_identity())
        for name, row in self.transitions.items():
            self.assertEqual(row["after"], current[name])
            old = dict(code=row["before"], manifest="data", assets="weights", statistics="stats")
            new = dict(old, code=row["after"])
            self.assertTrue(runtime.checkpoint_identity_compatible(old, new))
            self.assertFalse(runtime.checkpoint_identity_compatible(new, old))
            for key in old:
                self.assertFalse(runtime.checkpoint_identity_compatible(old, dict(new, **{key: "changed"})))
            self.assertFalse(runtime.checkpoint_identity_compatible(old, dict(new, extra="changed")))

    def test_all_audited_revisions_can_resume_after_inference_only_updates(self):
        ledger = runtime.read_json(ROOT / "physgen_v42/checkpoint_compatibility.json")
        for profile, latest in self.transitions.items():
            revisions = {row[key] for row in ledger["transitions"] if row["profile"] == profile
                         for key in ("before", "after")}
            for saved in revisions:
                with self.subTest(profile=profile, saved=saved):
                    self.assertTrue(runtime.checkpoint_code_compatible(saved, latest["after"]))
            self.assertFalse(runtime.checkpoint_code_compatible("unreviewed-source", latest["after"]))

    def run_loop_and_resume(self, profile, training, cfg, root, is_lora=False):
        with tempfile.TemporaryDirectory(prefix="checkpoint_loop_", dir=root / "tmp") as tmp:
            tmp = Path(tmp)
            for key in ("checkpoints", "logs", "cache"):
                cfg["paths"][key] = str(tmp / key)
            cache = Path(cfg["paths"]["cache"])
            cache.mkdir()
            dataset = TinyDataset()
            torch.save(dict(manifest_hash=runtime.digest(dataset.manifest), train_count=len(dataset)), cache / "stats.pt")
            torch.save(torch.zeros(1), cache / "negative.pt")
            (cache / "ready.json").write_text(json.dumps(dict(statistics_sha256=runtime.sha256(cache / "stats.pt"))))
            with ExitStack() as stack:
                # Only the expensive model/data and GPU-specific calls are substituted.
                # Do not mock log, save/load_checkpoint, AdamW, EMA, queues or scheduler.
                for name in ("synchronize", "reset_peak_memory_stats", "max_memory_allocated",
                             "max_memory_reserved", "memory_allocated"):
                    stack.enter_context(patch.object(torch.cuda, name, return_value=0))
                stack.enter_context(patch.object(torch.cuda, "get_device_name", return_value="CPU regression"))
                stack.enter_context(patch.object(training, "lock_assets", return_value={}))
                validation = stack.enter_context(patch.object(training, "health_check", return_value=0.))
                if is_lora:
                    stack.enter_context(patch.object(training, "check_data", return_value=(dataset, dataset)))
                    stack.enter_context(patch.object(training, "load_model", side_effect=lambda *a, **kw: TinyLoRA()))
                    stack.enter_context(patch.object(training, "train_micro", side_effect=lora_micro))
                else:
                    stack.enter_context(patch.object(training, "Dataset", TinyDataset))
                    stack.enter_context(patch.object(training, "Adapter", TinyAdapter))
                    stack.enter_context(patch.object(training, "load_wan", return_value=None))
                    stack.enter_context(patch.object(training, "load_vae", return_value=None))
                    stack.enter_context(patch.object(training, "Decoder", return_value=None))
                    stack.enter_context(patch.object(training, "ProcessWan", side_effect=lambda w, a: SimpleNamespace(adapter=a)))
                    stack.enter_context(patch.object(training, "train_step" if profile == "batch1" else "train_micro",
                                                     side_effect=batch1_micro if profile == "batch1" else adapter_micro))
                with redirect_stdout(io.StringIO()):
                    training.train(cfg, SimpleNamespace(resume=None, run_name="continuous"), torch.device("cpu"))
                run = tmp / "checkpoints/continuous"
                logs = tmp / "logs/continuous"
                checkpoints = [row for row in jsonlines(logs / "events.jsonl") if row["event"] == "checkpoint"]
                self.assertEqual([row["step"] for row in checkpoints], list(range(100, 1201, 100)))
                self.assertEqual([row["step"] for row in jsonlines(logs / "updates.jsonl") if row["event"] == "update"],
                                 list(range(1, 1201)))
                self.assertEqual(validation.call_count, 6)
                for row in checkpoints:
                    path = Path(row["path"])
                    self.assertEqual(path, run / f"step{row['step']:04d}")
                    marker = runtime.read_json(path / "complete.json")
                    runtime.verify_files(path, marker["files"], full=True)
                    self.assertEqual(marker["ema_updates"], row["step"])
                self.assertEqual(runtime.read_json(run / "final.json")["step"], 1200)
                self.assertEqual(runtime.read_json(tmp / "checkpoints/latest_final.json")["checkpoint"], str(run / "step1200"))

                # Simulate a pre-fix checkpoint, without altering any user artifact.
                resumed = tmp / "checkpoints/resumed/step0100"
                shutil.copytree(run / "step0100", resumed)
                marker = runtime.read_json(resumed / "complete.json")
                state = torch.load(resumed / "training.pt", weights_only=False, map_location="cpu")
                marker["identity"]["code"] = self.transitions[profile]["before"]
                state["identity"] = dict(marker["identity"])
                torch.save(state, resumed / "training.pt")
                marker["files"]["training.pt"] = runtime.file_identity(resumed / "training.pt")
                (resumed / "complete.json").write_text(json.dumps(marker))
                with redirect_stdout(io.StringIO()):
                    training.train(cfg, SimpleNamespace(resume=str(resumed), run_name=None), torch.device("cpu"))
                restored_logs = tmp / "logs/resumed"
                events = jsonlines(restored_logs / "events.jsonl")
                self.assertEqual(events[0]["step"], 100)
                self.assertEqual([row["step"] for row in events if row["event"] == "checkpoint"], list(range(200, 1201, 100)))
                self.assertEqual([row["step"] for row in jsonlines(restored_logs / "updates.jsonl") if row["event"] == "update"],
                                 list(range(101, 1201)))
                for filename in ("lora.pt" if is_lora else "adapter.pt", "ema.pt", "training.pt"):
                    self.assert_state_equal(torch.load(run / "step1200" / filename, weights_only=False, map_location="cpu"),
                                            torch.load(resumed.parent / "step1200" / filename, weights_only=False, map_location="cpu"))
                self.assertEqual(runtime.read_json(tmp / "checkpoints/latest_final.json")["checkpoint"],
                                 str(resumed.parent / "step1200"))

    def test_v42_save_continue_and_legacy_resume_100_to_1200(self):
        self.run_loop_and_resume("v42", v42_training, runtime.read_config(ROOT / "configs/stability.yaml"), ROOT)

    def test_batch1_save_continue_and_legacy_resume_100_to_1200(self):
        self.run_loop_and_resume("batch1", batch1_training, batch1_config(), ROOT)

    def test_lora_save_continue_and_legacy_resume_100_to_1200(self):
        self.run_loop_and_resume("lora", lora_training(), lora_config(), LORA_ROOT, is_lora=True)

    def test_four_gpu_loop_save_continue_and_legacy_resume_100_to_1200(self):
        self.run_loop_and_resume("four_gpu", four_training(), four_config(), LORA_ROOT, is_lora=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
