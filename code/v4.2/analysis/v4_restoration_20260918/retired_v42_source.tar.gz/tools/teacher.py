"""Sequential teacher jobs; this process exits before Wan generation starts."""
import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
if __name__ == "__main__":
    print("[inference] Loading JEPA environment ...", flush=True)
import torch
from physgen_v42.encoders import VideoTeacher
from physgen_v42.runtime import (read_json, require_environment, require_single_gpu, output_path,
                                save_tensor, save_json, log, job_lock)
from inference.conditions import file_stamp, image_cache, teacher_identity


def encode(root, phase):
    plan = read_json(root / "cases.json")
    paths = plan["config"]["paths"]
    pending = []
    for case in plan["cases"]:
        if phase == "anchors" and (case["mode"] != "i2v" or "gt_record" in case):
            continue
        folder = root / case["key"]
        name = "anchor" if phase == "anchors" else "generated_jepa"
        source = folder / ("first_image.pt" if phase == "anchors" else "generated_teacher_view.pt")
        destination = folder / (name + ".pt")
        stamp_path = folder / (name + ".meta.json")
        if phase == "generated" and read_json(folder / "metadata.json")["status"] != "completed":
            raise ValueError(f"Generation has not completed: {case['key']}")
        identity = teacher_identity(plan, case, source, phase)
        if destination.exists() and stamp_path.exists():
            stamp = read_json(stamp_path)
            if stamp["identity"] == identity:
                continue
        cached = image_cache(plan, case, "anchor") if phase == "anchors" else None
        if cached is not None and cached.exists():
            save_tensor(torch.load(cached, map_location="cpu", weights_only=True), destination)
            save_json(dict(identity=identity, file=file_stamp(destination)), stamp_path)
            log(event="anchor_cached", case=case["key"])
            continue
        pending.append((case, destination, source, stamp_path, identity))
    if not pending:
        log(event="teacher_reused", phase=phase)
        return
    log(event="loading", model="JEPA first-image encoder" if phase == "anchors" else "JEPA video evaluator",
        pending=len(pending))
    device = require_single_gpu()
    teacher = VideoTeacher(paths, device)
    for index, (case, destination, source, stamp_path, identity) in enumerate(pending, 1):
        view = torch.load(source, map_location=device, weights_only=True).float()
        if phase == "anchors":
            value = teacher(view, first_image=True)
        else:
            if view.shape != (1, 3, 32, 384, 384):
                raise ValueError("Expected the 32 fixed generated teacher frames")
            with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16, cache_enabled=False):
                value = teacher.encoder(((view + 1) * .5 - teacher.mean) / teacher.std, training=False)
            if value.shape != (1, 9216, 1664):
                raise ValueError("Unexpected V-JEPA generated-video shape")
            value = value.reshape(1, 16, 576, 1664)
        value = value.cpu().bfloat16()
        save_tensor(value, destination)
        if phase == "anchors":
            save_tensor(value, image_cache(plan, case, "anchor"))
        save_json(dict(identity=identity, file=file_stamp(destination)), stamp_path)
        log(event="teacher_encoded", case=case["key"], phase=phase, completed=index, total=len(pending))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", choices=("anchors", "generated"), required=True)
    args = parser.parse_args()
    require_environment("teacher")
    root = output_path(args.output)
    with job_lock(root / ".inference.lock"):
        encode(root, args.phase)


if __name__ == "__main__":
    main()
