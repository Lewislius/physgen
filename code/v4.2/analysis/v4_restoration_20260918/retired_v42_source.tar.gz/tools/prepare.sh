#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/runtime_env.sh"
config="${CONFIG:-${V42_ROOT}/configs/stability.yaml}"
stage="${STAGE:-auto}"
case "$stage" in
  auto)
    v42_python runtime "${V42_ROOT}/tools/bootstrap.py" --config "$config"
    ;;
  index|reuse)
    v42_python runtime "${V42_ROOT}/tools/prepare.py" --config "$config" --pass "$stage"
    ;;
  encode)
    v42_python runtime "${V42_ROOT}/tools/prepare.py" --config "$config" --pass vae
    v42_python runtime "${V42_ROOT}/tools/prepare.py" --config "$config" --pass text
    v42_python teacher "${V42_ROOT}/tools/prepare.py" --config "$config" --pass teacher
    v42_python runtime "${V42_ROOT}/tools/prepare.py" --config "$config" --pass finalize
    ;;
  audit)
    v42_python runtime "${V42_ROOT}/tools/prepare.py" --config "$config" --pass audit
    ;;
  *) echo 'STAGE must be auto, index, reuse, encode or audit' >&2; exit 2 ;;
esac
