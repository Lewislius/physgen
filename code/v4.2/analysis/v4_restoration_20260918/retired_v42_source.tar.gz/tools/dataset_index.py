"""v4 WISA selection, filename split, source captions, centre windows and image buckets."""
from collections import Counter
import hashlib
from pathlib import Path
import random

from physgen_v42 import VERSION
from physgen_v42.cache import compatible_preparation, encoding_config
from physgen_v42.runtime import (lock_assets, log, native_negative, preparation_fingerprint,
                                digest, read_json, save_json)


def frame_window(source_frames, limit=121, start_frame=None):
    available = source_frames if start_frame is None else source_frames - start_frame
    frames = 1 + 4 * ((min(available, limit) - 1) // 4)
    start = (source_frames - frames) // 2 if start_frame is None else start_frame
    if frames < 5 or start < 0:
        raise ValueError("Fewer than five usable frames")
    return list(range(start, start + frames))


def source_identity(path):
    stat = Path(path).stat()
    return dict(bytes=stat.st_size, mtime_ns=stat.st_mtime_ns)


def index(cfg):
    from physgen_v42.data import validate_records
    root, ann = Path(cfg["paths"]["cache"]), Path(cfg["paths"]["annotations"])
    root.mkdir(parents=True, exist_ok=True)
    ann.mkdir(parents=True, exist_ok=True)
    assets = lock_assets(cfg, create=True)
    manifest_path = root / "manifest.json"
    if manifest_path.exists():
        old = read_json(manifest_path)
        # Added selection provenance fields do not invalidate the existing quick16 tensors.
        def selection(data):
            return {k: v for k, v in data.items() if k not in ("source_limit", "subset_manifest")}
        if (selection(old["data_config"]) != selection(cfg["data"]) or old["assets"] != assets or
                not compatible_preparation(old.get("preparation_code"))):
            raise ValueError("Cache contains different encoding inputs; choose a separate destination to preserve it")
        validate_records(old["records"], cfg)
        if old.get("version") != VERSION or old["data_config"] != cfg["data"] or old["preparation_code"] != preparation_fingerprint():
            old.update(version=VERSION, data_config=cfg["data"], preparation_code=preparation_fingerprint())
            save_json(old, manifest_path)
        log(event="source_index_reused", records=len(old["records"]), source_counts=old["source_counts"])
        return
    subset = cfg["data"].get("subset_manifest")
    if subset and Path(subset).is_file():
        source = read_json(subset)
        if (not compatible_preparation(source.get("preparation_code")) or
                encoding_config(source["data_config"]) != encoding_config(cfg["data"]) or
                any(source["data_config"][k] != cfg["data"][k] for k in ("seed", "validation_stride"))):
            raise ValueError("Subset source differs from the selected source-window/split recipe")
        records = source["records"][:cfg["data"]["limit"]]
        if len(records) != cfg["data"]["limit"]:
            raise ValueError("Subset source does not contain enough valid indexed records")
        validate_records(records, cfg)
        _save_manifest(cfg, records, source.get("excluded", []), assets,
                       subset_source=dict(path=str(Path(subset).resolve()), manifest_hash=digest(source),
                                          selection="first_valid_records_preserve_original_split"))
        return
    # Only decode source headers when a compatible indexed subset is unavailable.
    import numpy as np
    from decord import VideoReader, cpu
    from physgen_v42.geometry import canvas, fit_geometry
    entries = read_json(cfg["paths"]["wisa_index"])
    if not isinstance(entries, list):
        raise ValueError("WISA index must be a list")
    data = cfg["data"]
    source_limit = data.get("source_limit", data["limit"])
    selected = list(range(len(entries)))[:source_limit] if source_limit else list(range(len(entries)))
    if data.get("selection_file"):
        selected = read_json(data["selection_file"])
    annotations = {r["index"]: r for r in read_json(data["clip_annotations"])} if data.get("clip_annotations") else {}
    names = list(dict.fromkeys(entries[i]["video_name"] for i in selected))
    random.Random(data["seed"]).shuffle(names)
    validation = set(names[::data["validation_stride"]])
    quick = cfg.get("purpose") == "quick16_pipeline_only"
    if quick:
        chosen = set(selected)
        selected += [i for i in range(len(entries)) if i not in chosen]
    records, excluded, seen_names = [], [], set()
    for number, i in enumerate(selected, 1):
        entry, annotation = entries[i], annotations.get(i)
        name = entry["video_name"]
        if quick and name in seen_names:
            continue
        path = (Path(cfg["paths"]["wisa_videos"]) / name).resolve()
        try:
            caption = annotation["caption"] if annotation else entry["captions"]
            if not isinstance(caption, str) or not caption.strip():
                raise ValueError("Missing original caption")
            identity = source_identity(path)
            view_path = ann / "views" / f"source{i:07d}.json"
            request = dict(source=str(path), identity=identity, caption=caption, annotation=annotation,
                           data_config=data)
            saved = read_json(view_path) if view_path.exists() else None
            if saved and saved["request"] == request:
                record = saved["record"]
            else:
                reader = VideoReader(str(path), ctx=cpu(0), num_threads=1)
                limit = min(data["frames"], annotation["frames"]) if annotation else data["frames"]
                indices = frame_window(len(reader), limit, annotation["start_frame"] if annotation else None)
                pts = reader.get_frame_timestamp(indices)[:, 0].astype(np.float64)
                if not np.isfinite(pts).all() or np.diff(pts).min() <= 0:
                    raise ValueError("Invalid source PTS")
                image = reader[indices[0]]
                h, w = canvas(image.shape[0], image.shape[1], data["max_long_side"], data["max_area"])
                geo = dict(fit_geometry(image.shape[0], image.shape[1], h, w, upscale=False), frames=len(indices))
                record = dict(id=f"source{i:07d}", index=i, video_name=name, video=str(path), source_file=identity,
                              source_id=hashlib.sha256(name.encode()).hexdigest(), caption=caption,
                              caption_scope="window" if annotation else "video", indices=indices, pts=pts.tolist(),
                              source_frames=len(reader), source_fps=float(reader.get_avg_fps()),
                              duration=float(pts[-1]-pts[0]), geometry=geo, category="unlabeled", interactions=[],
                              motion_peak=0, objects=[], objects_reliable=False)
                del reader
                save_json(dict(request=request, record=record), view_path)
            records.append(dict(record, split="validation" if name in validation else "train"))
            seen_names.add(name)
        except (OSError, RuntimeError, ValueError, KeyError) as error:
            excluded.append(dict(index=i, video_name=name, reason=str(error)))
            log(event="source_excluded", **excluded[-1])
        if number == 1 or number % 25 == 0 or quick:
            log(event="source_index", visited=number, accepted=len(records), excluded=len(excluded),
                target=16 if quick else len(selected))
        if quick and len(records) == 16:
            names = list(dict.fromkeys(r["video_name"] for r in records))
            random.Random(data["seed"]).shuffle(names)
            validation = set(names[::data["validation_stride"]])
            records = [dict(r, split="validation" if r["video_name"] in validation else "train") for r in records]
            break
        if not quick and data["limit"] and len(records) == data["limit"]:
            break
    if data["limit"] and len(records) != data["limit"]:
        raise ValueError(f"Need {data['limit']} valid clips; found {len(records)} in selected sources")
    validate_records(records, cfg)
    _save_manifest(cfg, records, excluded, assets)


def _save_manifest(cfg, records, excluded, assets, **provenance):
    from physgen_v42.data import stratified_order
    data = cfg["data"]
    diagnostics = {}
    for split, count in (("train", 16), ("validation", 24)):
        pool = [r for r in records if r["split"] == split]
        diagnostics[split] = [dict(id=pool[i]["id"], mode="t2v" if n % 4 == 3 else "i2v")
                              for n, i in enumerate(stratified_order(pool, data["seed"] + 53)[:count])]
    manifest = dict(version=VERSION, purpose=cfg.get("purpose", "training"), data_policy="v4_nativefps_center_window",
                    data_config=data, records=records, source_counts=dict(Counter(r["split"] for r in records)),
                    diagnostics=diagnostics, health_ids=[r["id"] for r in diagnostics["validation"][:16]],
                    excluded=excluded, assets=assets, negative_prompt=native_negative(),
                    preparation_code=preparation_fingerprint(), **provenance)
    save_json(manifest, Path(cfg["paths"]["cache"]) / "manifest.json")
    log(event="source_index_complete", records=len(records), source_counts=manifest["source_counts"],
        frame_counts=dict(Counter(len(r["indices"]) for r in records)), vlm_screening=False, object_tracking=False)
