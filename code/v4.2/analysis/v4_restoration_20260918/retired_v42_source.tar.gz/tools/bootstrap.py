"""Production startup: prepare a new event dataset from source videos, then allow training."""
import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from physgen_v42.runtime import (ROOT, job_lock, log, read_config,
                                require_environment, run_role, save_json)
from physgen_v42.cache import ready_valid


def ensure_data(cfg, config_path, resume=False):
    root = Path(cfg["paths"]["cache"])
    root.mkdir(parents=True, exist_ok=True)
    status_path = root / "preparation_status.json"
    def status(stage, **extra):
        value = dict(stage=stage, cache=str(root), **extra)
        save_json(value, status_path)
        log(event="data_preparation", **value)
    with job_lock(root / ".bootstrap.lock"):
        status("index", policy="first_valid_records_preserve_original_split")
        run_role("runtime", "tools/prepare.py", "--config", config_path, "--pass", "index")
        if ready_valid(cfg):
            status("ready", message="Manifest, statistics and all component files verified.")
            return
        for name in ("vae", "text", "teacher", "finalize"):
            status(name, policy="reuse_valid_generate_missing", resume=resume)
            run_role("teacher" if name == "teacher" else "runtime", "tools/prepare.py",
                     "--config", config_path, "--pass", name)
        status("ready", message="Source indexing and encoding completed; entering training.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(ROOT / "configs/stability.yaml"))
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    require_environment("runtime")
    cfg = read_config(args.config)
    try:
        ensure_data(cfg, str(Path(args.config).resolve()), resume=args.resume)
    except BaseException as error:
        log(event="preparation_stopped", error=f"{type(error).__name__}: {error}",
            status_file=str(Path(cfg["paths"]["cache"]) / "preparation_status.json"))
        raise


if __name__ == "__main__":
    main()
