"""v4-style source indexing followed by sequential VAE/T5/JEPA encoding."""
import argparse
from collections import Counter
from pathlib import Path
import shutil
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.dataset_index import index, source_identity
from physgen_v42.cache import CACHE_ERRORS, CacheStore, ready_valid, validate
from physgen_v42.runtime import (ROOT, digest, lock_assets, log, read_config,
                                read_json, require_environment, require_single_gpu,
                                save_json, save_tensor, sha256, job_lock, preparation_fingerprint,
                                file_identity, verify_files)


def scan(cfg, manifest, stage):
    store = CacheStore(cfg, manifest)
    pending, counts = [], Counter()
    stages = ("teacher", "anchors") if stage == "teacher" else (stage,)
    try:
        for n, record in enumerate(manifest["records"], 1):
            missing = []
            for component in stages:
                result = store.ensure(component, record)
                counts[f"{component}_{result}"] += 1
                if result == "missing":
                    missing.append(component)
            if missing:
                pending.append((record, missing))
            if n % 100 == 0:
                store.save()
                log(event="cache_checked", stage=stage, checked=n, total=len(manifest["records"]), **counts)
        negative_needed = False
        if stage == "text":
            result = store.ensure("text", manifest["records"][0], negative=True)
            counts[f"negative_{result}"] += 1
            negative_needed = result == "missing"
    finally:
        store.save()
    log(event="cache_scan", stage=stage, pending=len(pending), negative_needed=negative_needed, **counts)
    return store, pending, negative_needed, dict(counts)


def reuse(cfg):
    """CPU-only promotion of available caches; encoding missing parts is deferred to startup."""
    index(cfg)
    manifest = read_json(Path(cfg["paths"]["cache"]) / "manifest.json")
    status = {}
    for stage in ("vae", "text", "teacher"):
        _, pending, negative, counts = scan(cfg, manifest, stage)
        status[stage] = dict(pending=len(pending), negative_needed=negative, **counts)
    save_json(status, Path(cfg["paths"]["cache"]) / "reuse_status.json")
    return status


def encode(cfg, stage):
    import torch
    root = Path(cfg["paths"]["cache"])
    manifest = read_json(root / "manifest.json")
    if manifest["assets"] != lock_assets(cfg) or manifest["data_config"] != cfg["data"]:
        raise ValueError("Cache inputs changed")
    if manifest.get("preparation_code") != preparation_fingerprint():
        raise ValueError("Preprocessing code changed after the manifest was frozen")
    store, pending, negative_needed, counts = scan(cfg, manifest, stage)
    if not pending and not negative_needed:
        log(event="cache_reused", stage=stage, encoder_loaded=False, **counts)
        return
    # Estimate only missing components after reuse, including temporary writes.
    sizes = {"vae": 24, "text": 5, "teacher": 32, "anchors": 2}
    estimate = (sum(sizes[s] for _, missing in pending for s in missing) + 5 * negative_needed) * 1024**2
    if shutil.disk_usage(root).free < estimate + 5 * 1024**3:
        raise RuntimeError(f"Insufficient cache disk space: need approximately {estimate / 2**30:.1f} GiB plus margin")
    from physgen_v42.data import read_window
    from physgen_v42.encoders import VideoTeacher, encode_vae, load_text, load_vae
    device = require_single_gpu()
    log(event="encoder_loading", stage=stage, pending=len(pending), python=sys.executable)
    encoder = load_vae(cfg["paths"], device) if stage == "vae" else load_text(cfg["paths"], device) if stage == "text" else VideoTeacher(cfg["paths"], device)
    with torch.no_grad():
        if negative_needed:
            with torch.autocast("cuda", dtype=torch.bfloat16, cache_enabled=False):
                value = encoder([manifest["negative_prompt"]], device)[0].cpu().bfloat16()
            validate("text", value, manifest["records"][0])
            save_tensor(value, root / "negative.pt")
            store.remember("text", manifest["records"][0], negative=True)
            store.save()
        for n, (record, missing) in enumerate(pending, 1):
            if cfg.get("purpose") == "quick16_pipeline_only":
                log(event="encoding_sample", stage=stage, count=n, total=len(pending), id=record["id"],
                    frames=len(record["indices"]), height=record["geometry"]["h"], width=record["geometry"]["w"])
            if stage == "text":
                with torch.autocast("cuda", dtype=torch.bfloat16, cache_enabled=False):
                    value = encoder([record["caption"]], device)[0].cpu().bfloat16()
            else:
                if source_identity(record["video"]) != record["source_file"]:
                    raise ValueError("Source video changed since indexing")
                video = read_window(record, device)
                if stage == "vae":
                    value = dict(latent=encode_vae(encoder, video).cpu(), first=encode_vae(encoder, video[:, :, :1]).cpu())
                else:
                    if "teacher" in missing:
                        value = encoder(video).cpu().bfloat16()
                    if "anchors" in missing:
                        anchor = encoder(video[:, :, :1], first_image=True).cpu().bfloat16()
                        validate("anchors", anchor, record)
                        save_tensor(anchor, root / "anchors" / (record["id"] + ".pt"))
                        store.remember("anchors", record)
                del video
            if stage in missing:
                validate(stage, value, record)
                save_tensor(value, root / stage / (record["id"] + ".pt"))
                store.remember(stage, record)
            if cfg.get("purpose") == "quick16_pipeline_only" or n == 1 or n % 25 == 0 or n == len(pending):
                store.save()
                log(event="encoded", stage=stage, count=n, pending=len(pending), id=record["id"])


def finalize(cfg, audit_only=False):
    import torch
    from physgen_v42.geometry import Geometry
    from physgen_v42.data import validate_records
    root = Path(cfg["paths"]["cache"])
    manifest = read_json(root / "manifest.json")
    validate_records(manifest["records"], cfg)
    if manifest.get("preparation_code") != preparation_fingerprint():
        raise ValueError("Preprocessing code changed after manifest creation")
    if manifest["assets"] != lock_assets(cfg):
        raise ValueError("Assets changed after manifest creation")
    if audit_only:
        ready = read_json(root / "ready.json")
        if ready["manifest_hash"] != digest(manifest) or ready["statistics_sha256"] != sha256(root / "stats.pt"):
            raise ValueError("Manifest/statistics changed after finalization")
        verify_files(root, ready["files"], full=True)
        log(event="cache_audit", records=len(manifest["records"]), files=len(ready["files"]))
        return
    if ready_valid(cfg):
        log(event="cache_finalization_reused", records=len(manifest["records"]))
        return
    sums = dict(z2=0., z_n=0., v2=0., v_n=0.)
    mu = torch.zeros(576, 1664, dtype=torch.float64)
    mu_weight = torch.zeros(576, 1, dtype=torch.float64)
    files = {}
    for record in manifest["records"]:
        geo = Geometry.build(record["geometry"], torch.device("cpu"))
        values = {}
        for stage in ("vae", "text", "teacher", "anchors"):
            path = root / stage / (record["id"] + ".pt")
            value = torch.load(path, map_location="cpu", weights_only=True)
            validate(stage, value, record)
            values[stage] = value
            files[str(path.relative_to(root))] = file_identity(path)
        if record["split"] == "train":
            weight = geo.p_weight.double()
            target = values["teacher"].double()[0]
            sums["z2"] += float((target.square() * weight[None, :, None]).sum())
            sums["z_n"] += float(weight.sum()) * 16 * 1664
            mu += values["anchors"].double()[0] * weight[:, None]
            mu_weight += weight[:, None]
            latent = values["vae"]["latent"].float()
            generator = torch.Generator().manual_seed(cfg["data"]["seed"] + int(record["id"].replace("source", "")))
            target_v = torch.randn(latent.shape, generator=generator) - latent
            sums["v2"] += float(target_v.double().square().sum())
            sums["v_n"] += target_v.numel()
    negative = torch.load(root / "negative.pt", map_location="cpu", weights_only=True)
    validate("text", negative, manifest["records"][0])
    files["negative.pt"] = file_identity(root / "negative.pt")
    stats = dict(mu_first=(mu / mu_weight.clamp_min(1e-12)).float(),
                 s_z=(sums["z2"] / sums["z_n"]) ** .5, s_v=(sums["v2"] / sums["v_n"]) ** .5,
                 train_count=sum(r["split"] == "train" for r in manifest["records"]), manifest_hash=digest(manifest), teacher_mean_area=mu_weight.float())
    if min(stats["s_z"], stats["s_v"]) <= 0:
        raise ValueError("Training calibration has zero/invalid RMS")
    # Repaired files can have new mtimes but identical contents. Preserve the
    # original statistics archive when its values match, so valid resumes keep
    # their checkpoint's statistics identity (torch.save archives are not byte-stable).
    same_stats = False
    try:
        previous = torch.load(root / "stats.pt", map_location="cpu", weights_only=True)
        same_stats = isinstance(previous, dict) and previous.keys() == stats.keys() and all(
            torch.equal(value, previous[key]) if isinstance(value, torch.Tensor) else value == previous[key]
            for key, value in stats.items())
    except CACHE_ERRORS:
        pass
    if not same_stats:
        save_tensor(stats, root / "stats.pt")
    save_json(dict(manifest_hash=digest(manifest), files=files, statistics_sha256=sha256(root / "stats.pt"),
                   source_counts=dict(Counter(r["split"] for r in manifest["records"]))), root / "ready.json")
    log(event="cache_finalized", records=len(manifest["records"]), statistics_reused=same_stats)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(ROOT / "configs/stability.yaml"))
    parser.add_argument("--pass", dest="stage", required=True,
                        choices=("assets", "index", "reuse", "vae", "text", "teacher", "finalize", "audit"))
    args = parser.parse_args()
    require_environment("teacher" if args.stage == "teacher" else "runtime")
    cfg = read_config(args.config)
    import torch
    torch.set_num_threads(min(torch.get_num_threads(), 4))
    for key in ("annotations", "cache"):
        Path(cfg["paths"][key]).mkdir(parents=True, exist_ok=True)
    with job_lock(Path(cfg["paths"]["cache"]) / ".prepare.lock"):
        if args.stage == "assets":
            log(event="asset_lock", files=len(lock_assets(cfg, create=True)))
        elif args.stage == "index":
            index(cfg)
        elif args.stage == "reuse":
            reuse(cfg)
        elif args.stage in ("vae", "text", "teacher"):
            encode(cfg, args.stage)
        else:
            finalize(cfg, audit_only=args.stage == "audit")


if __name__ == "__main__":
    main()
