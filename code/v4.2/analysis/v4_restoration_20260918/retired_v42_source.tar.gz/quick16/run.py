"""Six real updates over 12 training clips, four held-out clips, and saved-model inference."""
import argparse
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from physgen_v42.runtime import (ROOT, code_fingerprint, digest, job_lock, log, output_path,
                                read_config, read_json, require_environment, save_json, sha256)


def configuration(path):
    import yaml
    settings = yaml.safe_load(Path(path).read_text().replace("${V42_ROOT}", str(ROOT)))
    expected = dict(purpose="quick16_pipeline_only", train_samples=12, validation_samples=4,
                    epochs=2, accumulation=4, schedule_steps=[1, 100, 800, 801, 802, 1200], inference_steps=4)
    for key, value in expected.items():
        if settings.get(key) != value:
            raise ValueError(f"Quick16 requires {key}={value}")
    cfg = read_config(settings["base_config"])
    work = output_path(settings["work_dir"])
    if (ROOT / "quick16" / "work") != work:
        raise ValueError("Quick16 uses its own quick16/work directory")
    cfg.update(purpose=settings["purpose"], quick16=settings)
    for key, suffix in dict(cache="cache_v4_f121", annotations="data_index", asset_lock="assets_wan_jepa_metadata.json",
                            checkpoints="checkpoints", logs="logs", outputs="inference_outputs").items():
        cfg["paths"][key] = str(work / suffix)
    cfg["data"].update(limit=16, source_limit=16, subset_manifest=None,
                       validation_stride=4, selection_file=None, clip_annotations=None)
    cfg["train"].update(steps=6, accumulation=4, save_every=6)
    cfg["inference"]["steps"] = 4
    return cfg


def implementation_identity():
    files = code_fingerprint()
    files.update({str(p.relative_to(ROOT)): sha256(p) for p in (ROOT / "quick16").glob("*.py")})
    return digest(files)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(ROOT / "configs/quick16.yaml"))
    parser.add_argument("--phase", required=True,
                        choices=("index", "vae", "text", "teacher", "finalize", "train", "infer"))
    args = parser.parse_args()
    require_environment("teacher" if args.phase == "teacher" else "runtime")
    cfg = configuration(args.config)
    work = Path(cfg["quick16"]["work_dir"])
    work.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    status = work / "status.json"
    with job_lock(work / ".phase.lock"):
        if args.phase == "index":
            (work / "SUCCESS.json").unlink(missing_ok=True)
        save_json(dict(phase=args.phase, status="running", purpose=cfg["purpose"]), status)
        log(event="quick_phase_start", phase=args.phase, train_samples=12, validation_samples=4, epochs=2)
        try:
            if args.phase == "index":
                from quick16.prepare import index
                index(cfg)
            elif args.phase in ("vae", "text", "teacher", "finalize"):
                from tools.prepare import encode, finalize
                finalize(cfg) if args.phase == "finalize" else encode(cfg, args.phase)
            elif args.phase == "train":
                from quick16.training import train
                train(cfg)
            else:
                from quick16.inference import infer
                infer(cfg)
        except BaseException as error:
            save_json(dict(phase=args.phase, status="failed", error=f"{type(error).__name__}: {error}"), status)
            log(event="quick_phase_failed", phase=args.phase, error=f"{type(error).__name__}: {error}")
            raise
        elapsed = time.perf_counter() - started
        save_json(dict(phase=args.phase, status="completed", seconds=elapsed, purpose=cfg["purpose"]), status)
        log(event="quick_phase_complete", phase=args.phase, seconds=elapsed)


if __name__ == "__main__":
    main()
