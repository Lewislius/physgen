# 16条数据、两轮训练

```bash
cd /home/liuzhirui/Project/physGen/code/v4.2
det experiment create train/train_quick16_2epochs_1x96g.yaml .
```

数据处理与正式版共用`tools/dataset_index.py`：WISA原caption、原fps、连续中心窗，视频上限121帧，短片保留4k+1帧；原v4尺寸桶最长边512/面积147456，不放大小图。没有Qwen/SAM，也没有全量权重哈希。取前16个可用源视频，seed打乱文件名后每4个取一个验证，共12 train/4 validation。

自动依次执行索引、FP32 VAE、T5、32帧JEPA及首图锚点、训练集定标、两轮真实训练、留出验证、保存checkpoint、新进程加载EMA、I2V/T2V各一条4步UniPC视频。所有输出隔离在`quick16/work/`。数据处理阶段可复用已完成的中间结果；训练重新提交时创建新的run。

12条训练数据每条恰好曝光两次；每次累积4条、3 I2V/1 T2V，共6次优化器更新。六步依次使用正式日程的1/100/800/801/802/1200设置，覆盖从第1步开始的FM联合训练、可微VAE时间差分反向和第801步开始的一步修复。真实基座与正式`train_micro`被直接复用；两套corrector各自含独立reader/core/writer。FM/struct按4归约，STRUCT基础系数0.10、仅更新两个core，其梯度最多占全模型生成梯度与自身梯度两路范数之和的20%；每步唯一temp保留0.05权重。EMA从第一步累计，共更新6次。它不是正式1200步训练的效果替代品。

每阶段、每条编码和每次训练曝光开始时均输出日志；失败记录到`quick16/work/status.json`并退出。只有训练、验证、保存/加载及两个视频导出全部成功后才发布`quick16/work/SUCCESS.json`和`quick_pipeline_passed`日志，文件内有视频路径。

4步视频仅验证生成链路，不能用于判断最终画质或物理效果。此短任务没有生成后的JEPA报告；原始模型仍要从磁盘加载，不能承诺固定几分钟完成。
