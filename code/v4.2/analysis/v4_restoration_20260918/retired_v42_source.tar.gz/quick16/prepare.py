"""Use the same v4-style WISA indexer as formal training, limited to 16 usable inputs."""
from tools.dataset_index import index
