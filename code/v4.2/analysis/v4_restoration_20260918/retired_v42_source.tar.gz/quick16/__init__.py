"""An isolated short run using the actual v4.2 model, encoders and training microstep."""
