"""Reload the saved quick EMA in a fresh process and export one I2V and one T2V clip."""
from pathlib import Path
import time

import torch

from physgen_v42.backbone import ProcessWan, fix_first, load_wan
from physgen_v42.data import Dataset
from physgen_v42.encoders import Decoder, load_vae
from physgen_v42.geometry import Geometry
from physgen_v42.model import Adapter
from physgen_v42.runtime import (autocast, checkpoint_code_compatible, digest, file_identity, lock_assets, log, read_json,
                                require_single_gpu, save_json, save_tensor, sha256, verify_files)
from quick16.run import implementation_identity


@torch.no_grad()
def infer(cfg):
    import imageio.v2 as imageio
    from wan.utils.fm_solvers_unipc import FlowUniPCMultistepScheduler
    device = require_single_gpu()
    latest = read_json(Path(cfg["paths"]["checkpoints"]) / "latest_quick.json")
    checkpoint = Path(latest["checkpoint"])
    complete = read_json(checkpoint / "complete.json")
    if complete["purpose"] != cfg["purpose"] or complete["step"] != 6 or complete["ema_updates"] != 6:
        raise ValueError("Expected the completed two-epoch quick checkpoint")
    verify_files(checkpoint, complete["files"], full=True)
    if (not checkpoint_code_compatible(complete["identity"]["code"], implementation_identity())
            or complete["identity"]["config"] != digest(cfg)):
        raise ValueError("Quick inference differs from saved code/config")
    if complete["identity"]["assets"] != digest(lock_assets(cfg)):
        raise ValueError("Quick model assets changed after training")
    dataset = Dataset(cfg, "validation")
    cache = Path(cfg["paths"]["cache"])
    if (complete["identity"]["manifest"] != digest(dataset.manifest) or
            complete["identity"]["statistics"] != sha256(cache / "stats.pt")):
        raise ValueError("Quick inference data/statistics changed")
    output = Path(cfg["paths"]["outputs"]) / checkpoint.name
    output.mkdir(parents=True, exist_ok=True)
    values = torch.load(checkpoint / "ema.pt", map_location="cpu", weights_only=True)
    adapter = Adapter(cfg, {k: values[k] for k in ("mu_first", "s_z", "s_v")}).float()
    adapter.load_state_dict(values, strict=True)
    del values
    adapter.eval().requires_grad_(False).to(device)
    log(event="quick_inference_loading", checkpoint=str(checkpoint), cases=2, solver_steps=4)
    model = ProcessWan(load_wan(cfg["paths"]["wan_checkpoint"], device), adapter, recompute=False).eval()
    decoder = Decoder(load_vae(cfg["paths"], device), recompute=False, save_on_cpu=False)
    negative = torch.load(cache / "negative.pt", map_location=device, weights_only=True)[None]
    outputs = []
    for index, mode in enumerate(("i2v", "t2v")):
        started = time.perf_counter()
        record = dataset.records[index]
        name = record["id"] + ".pt"
        geo = Geometry.build(record["geometry"], device)
        text = torch.load(cache / "text" / name, map_location=device, weights_only=True)[None]
        first = anchor = None
        if mode == "i2v":
            first = torch.load(cache / "vae" / name, map_location="cpu", weights_only=True)["first"].to(device)
            anchor = torch.load(cache / "anchors" / name, map_location=device, weights_only=True).float()
        generator = torch.Generator(device=device).manual_seed(42)
        h, w = record["geometry"]["h"], record["geometry"]["w"]
        frames = len(record["indices"])
        x = fix_first(torch.randn((1,48,1 + (frames - 1) // 4,h // 16,w // 16), device=device, generator=generator), first)
        sampler = FlowUniPCMultistepScheduler(num_train_timesteps=1000, shift=1, use_dynamic_shifting=False)
        sampler.set_timesteps(4, device=device, shift=5)
        with autocast(device):
            p0 = adapter.initialize(text, geo, mode, anchor)
        folder = output / mode
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "trajectory.jsonl").write_text("")
        for step, timestep in enumerate(sampler.timesteps):
            with autocast(device):
                result = model(x, first, text, sampler.sigmas[step].to(device=device, dtype=torch.float32),
                               record["duration"], geo, p0, negative)
            x = sampler.step(result["guided"].float(), timestep, x.float(), return_dict=False, generator=generator)[0]
            x = fix_first(x, first)
            if not bool(torch.isfinite(x).all()):
                raise FloatingPointError(f"Quick {mode} inference produced nonfinite values")
            log(folder / "trajectory.jsonl", event="quick_solver", mode=mode, step=step + 1, steps=4,
                sigma=float(sampler.sigmas[step]), metrics=result["metrics"])
            del result
        video = folder / "video.mp4"
        frame_count = 0
        with imageio.get_writer(str(video), fps=(frames - 1) / record["duration"], codec="libx264", quality=8,
                               macro_block_size=16) as writer:
            for frame in decoder.frames(x):
                if not bool(torch.isfinite(frame).all()):
                    raise FloatingPointError("Quick FP32 VAE export produced a nonfinite frame")
                writer.append_data((frame.clamp(0,1) * 255).round().byte().permute(1,2,0).cpu().numpy())
                frame_count += 1
        if frame_count != frames:
            raise RuntimeError(f"Exported {frame_count} frames; expected {frames}")
        save_tensor(x.cpu(), folder / "final_latent.pt")
        metadata = dict(purpose=cfg["purpose"], mode=mode, source=record["id"], prompt=record["caption"],
                        checkpoint=str(checkpoint), frames=frame_count, steps=4, duration=record["duration"],
                        seconds=time.perf_counter()-started, quality_evaluation=False,
                        video=file_identity(video), peak_allocated_gib=torch.cuda.max_memory_allocated(device)/2**30)
        save_json(metadata, folder / "metadata.json")
        outputs.append(str(video))
        log(event="quick_video_complete", mode=mode, video=str(video), frames=frame_count)
    result = dict(status="passed", purpose=cfg["purpose"], checkpoint=str(checkpoint), videos=outputs,
                  source_clips=16, training_clips=12, validation_clips=4, epochs=2, optimizer_updates=6,
                  training_coverage=complete["coverage"], frame_shape="v4 native-fps centre windows, up to 121 frames, area <=147456",
                  skipped=["full-weight SHA256", "generated JEPA report"],
                  generation_quality="not_evaluated; four-step samples are only for pipeline verification")
    save_json(result, output / "SUCCESS.json")
    save_json(result, Path(cfg["quick16"]["work_dir"]) / "SUCCESS.json")
    log(event="quick_pipeline_passed", summary=str(Path(cfg["quick16"]["work_dir"]) / "SUCCESS.json"), videos=outputs)
