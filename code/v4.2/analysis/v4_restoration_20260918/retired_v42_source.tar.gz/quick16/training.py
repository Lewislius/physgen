"""Two exact epochs; real production microsteps with a compressed phase schedule."""
from datetime import datetime, timezone
from pathlib import Path
import random
import time
import uuid

import torch

from physgen_v42.backbone import ProcessWan, load_wan
from physgen_v42.data import Dataset
from physgen_v42.encoders import Decoder, load_vae
from physgen_v42.model import Adapter
from physgen_v42.optim import EMA, GradientMixer, optimizer_for, rng_state, set_schedule
from physgen_v42.runtime import (digest, file_identity, lock_assets, log, read_json, require_single_gpu,
                                save_json, save_tensor, seed_all, sha256)
from quick16.run import implementation_identity
from train.train import health_check, norm_group, train_micro


def batches(cfg):
    counts = [0] * 12
    steps = cfg["quick16"]["schedule_steps"]
    for epoch in range(2):
        order = list(range(12))
        random.Random(cfg["train"]["seed"] + epoch).shuffle(order)
        for batch in range(3):
            step = epoch * 3 + batch + 1
            t2v_slot = (step - 1) % 4
            temporal_slot = t2v_slot if step in (3, 5) else (t2v_slot + 1) % 4
            exposures = []
            for slot, index in enumerate(order[4 * batch:4 * batch + 4]):
                active = slot == temporal_slot
                exposures.append(dict(index=index, mode="t2v" if slot == t2v_slot else "i2v",
                                      temporal=active, repair=active and steps[step - 1] >= 801,
                                      exposure=counts[index]))
                counts[index] += 1
            yield step, epoch + 1, steps[step - 1], exposures


def train(cfg):
    device = require_single_gpu()
    seed_all(cfg["train"]["seed"])
    dataset, validation = Dataset(cfg, "train"), Dataset(cfg, "validation", require_complete=False)
    cache = Path(cfg["paths"]["cache"])
    ready = read_json(cache / "ready.json")
    assets = lock_assets(cfg)
    if assets != dataset.manifest["assets"] or sha256(cache / "stats.pt") != ready["statistics_sha256"]:
        raise ValueError("Quick dataset assets/statistics changed")
    stats = torch.load(cache / "stats.pt", map_location="cpu", weights_only=True)
    if stats["train_count"] != 12 or stats["manifest_hash"] != digest(dataset.manifest):
        raise ValueError("Quick statistics must use only these 12 training clips")
    identity = dict(manifest=digest(dataset.manifest), statistics=ready["statistics_sha256"],
                    assets=digest(assets), code=implementation_identity(), config=digest(cfg))
    run = "quick16_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid.uuid4().hex[:6]
    checkpoint = Path(cfg["paths"]["checkpoints"]) / run
    logs = Path(cfg["paths"]["logs"]) / run
    checkpoint.mkdir(parents=True)
    save_json(dict(config=cfg, identity=identity, purpose=cfg["purpose"]), logs / "run.json")
    log(event="quick_model_loading", model="Wan2.2-TI2V-5B and FP32 VAE", max_frames=121,
        train_samples=12, validation_samples=4, epochs=2, updates=6)
    adapter = Adapter(cfg, stats).float().to(device)
    model = ProcessWan(load_wan(cfg["paths"]["wan_checkpoint"], device), adapter)
    decoder = Decoder(load_vae(cfg["paths"], device), save_on_cpu=cfg["train"]["decoder_save_on_cpu"])
    optimizer = optimizer_for(adapter, cfg)
    negative = torch.load(cache / "negative.pt", map_location=device, weights_only=True)[None]
    ema = EMA(adapter, cfg["train"]["ema_decay"])
    counts = [0] * 12
    coverage = dict(joint=0, repair_updates=0, temporal=0, repair_exposures=0, i2v=0, t2v=0)
    updated_groups = {name: False for name in adapter.groups()}
    for step, epoch, schedule_step, exposures in batches(cfg):
        started = time.perf_counter()
        set_schedule(adapter, optimizer, cfg, schedule_step)
        optimizer.zero_grad(set_to_none=True)
        mixer = GradientMixer(adapter.core_parameters(), adapter.parameters())
        totals = dict(fm=0., struct=0., temp=0.)
        phase = "repair" if schedule_step >= 801 else "joint"
        coverage["repair_updates" if phase == "repair" else phase] += 1
        for micro, exposure in enumerate(exposures):
            log(event="quick_micro_start", step=step, total_steps=6, epoch=epoch, micro=micro + 1,
                mode=exposure["mode"], temporal=exposure["temporal"], repair=exposure["repair"])
            sample = dataset.load(exposure["index"], exposure["mode"], device)
            values = train_micro(model, decoder, sample, exposure, schedule_step, mixer, negative,
                                 accumulation=4, loss_weights=cfg["loss"])
            log(logs / "micro.jsonl", event="quick_micro", step=step, epoch=epoch, schedule_step=schedule_step,
                micro=micro, id=sample["record"]["id"], mode=exposure["mode"], **values)
            for key in totals:
                totals[key] += values["weighted_" + key]
            counts[exposure["index"]] += 1
            coverage[exposure["mode"]] += 1
            coverage["temporal"] += int(exposure["temporal"])
            coverage["repair_exposures"] += int(exposure["repair"])
            del sample
        combined = mixer.combine(max_share=cfg["train"]["aux_ratio"])
        norms = {name: norm_group(module) for name, module in adapter.groups().items()}
        for name, value in norms.items():
            updated_groups[name] |= value > 0
        total_norm = torch.nn.utils.clip_grad_norm_(adapter.parameters(), 1., error_if_nonfinite=True)
        optimizer.step()
        ema.update(adapter)
        del mixer
        torch.cuda.synchronize(device)
        log(logs / "updates.jsonl", event="quick_update", step=step, total_steps=6, epoch=epoch,
            phase=phase, schedule_step=schedule_step, seconds=time.perf_counter() - started,
            losses=totals, grad_groups=norms, global_grad_norm=float(total_norm), **combined,
            peak_allocated_gib=torch.cuda.max_memory_allocated(device) / 2**30,
            peak_reserved_gib=torch.cuda.max_memory_reserved(device) / 2**30)
    if counts != [2] * 12 or ema.updates != 6 or not all(updated_groups.values()):
        raise RuntimeError(f"Incomplete two-epoch/gradient coverage: counts={counts}, groups={updated_groups}")
    log(event="quick_validation_start", records=4)
    validation_loss = health_check(model, validation, 1200, logs / "health.jsonl")
    log(event="quick_checkpoint_save", checkpoint=str(checkpoint), validation_loss=validation_loss)
    save_json(cfg, checkpoint / "config.json")
    save_tensor({k: v.detach().cpu() for k, v in adapter.state_dict().items()}, checkpoint / "adapter.pt")
    ema_values = {k: v.detach().cpu() for k, v in adapter.state_dict().items()}
    ema_values.update({k: v.detach().cpu() for k, v in ema.values.items()})
    save_tensor(ema_values, checkpoint / "ema.pt")
    save_tensor(dict(step=6, epochs=2, optimizer=optimizer.state_dict(), ema=ema.state_dict(), rng=rng_state(),
                     schedule_steps=cfg["quick16"]["schedule_steps"], counts=counts, identity=identity,
                     purpose=cfg["purpose"]), checkpoint / "training.pt")
    names = ("config.json", "adapter.pt", "ema.pt", "training.pt")
    complete = dict(purpose=cfg["purpose"], step=6, epochs=2, ema_updates=6, identity=identity,
                    coverage=coverage, clips_seen_per_epoch=12, exposures_per_clip=counts,
                    nonzero_gradient_groups=updated_groups, validation_loss=validation_loss,
                    files={name: file_identity(checkpoint / name) for name in names})
    save_json(complete, checkpoint / "complete.json")
    save_json(dict(checkpoint=str(checkpoint), **complete), Path(cfg["paths"]["checkpoints"]) / "latest_quick.json")
    log(event="quick_training_complete", checkpoint=str(checkpoint), epochs=2, updates=6, coverage=coverage)
