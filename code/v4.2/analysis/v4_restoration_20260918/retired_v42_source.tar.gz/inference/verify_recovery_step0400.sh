#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/../tools/runtime_env.sh"
export V42_DIRECT_PYTHON=1
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
checkpoint="${V42_ROOT}/checkpoints/v4_joint_20260918T034836Z_16183b/step0400"
output="${V42_ROOT}/inference_outputs/v4_joint_step0400_raw_v4matched_r4_verification"
v42_python runtime "${V42_ROOT}/inference/infer.py" --phase prepare --checkpoint "$checkpoint" \
  --output "$output" --suite demo --profile v4_matched --weights raw --case-keys P01_i2v P01_t2v
v42_python teacher "${V42_ROOT}/tools/teacher.py" --phase anchors --output "$output"
v42_python runtime "${V42_ROOT}/inference/infer.py" --phase sample --output "$output"
