"""Delta-H plots and strictly paired video-review manifests; no teacher required."""
import argparse
import csv
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from physgen_v42.runtime import digest, output_path, read_json, read_jsonl, save_json


QUALITY_FIELDS = ('imaging_artifact', 'identity_shape_failure', 'deformation_during_motion',
                  'prompt_object_action_failure', 'contact_response_failure',
                  'visible_interpenetration', 'color_flicker', 'event_incomplete', 'static_video')


def report_case(folder):
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    rows = read_jsonl(folder/'trajectory.jsonl')
    if not rows:
        raise ValueError('No solver trajectory to report')
    steps = [r['step']+1 for r in rows]
    summary = dict(solver_calls=len(rows), writers={},
                   caveat='Amplitude, roughness and CFG alignment are diagnostics, not physical or semantic scores')
    fig, axes = plt.subplots(4,1,figsize=(10,12),constrained_layout=True)
    maps = []
    for name in ('writer5','writer15'):
        available = [r for r in rows if 'delta_h' in r['metrics'].get(name,{})]
        if not available:
            continue
        values = [r['metrics'][name] for r in available]
        xs = [r['step']+1 for r in available]
        axes[0].plot(xs,[v['mean_ratio'] for v in values],label=name+' frame/reference')
        axes[0].plot(xs,[v['delta_h']['token_ratio_p99'] for v in values],ls='--',label=name+' token p99/H')
        axes[1].plot(xs,[v['compression'] for v in values],label=name+' effective/candidate')
        gates = [(x,v['gate_mean']) for x,v in zip(xs,values) if 'gate_mean' in v]
        if gates:
            axes[1].plot(*zip(*gates),ls=':',label=name+' gate')
        profile = np.array([v['delta_h']['frame_relative_rms'] for v in values])
        summary['writers'][name] = dict(
            max_frame_reference_ratio=max(max(v['frame_ratio']) for v in values),
            max_token_ratio_to_current_h=max(v['delta_h']['token_ratio_max'] for v in values),
            max_near_budget_fraction=max(v['frame_near_budget_fraction'] for v in values),
            peak_step=xs[int(profile.max(axis=1).argmax())],
            mean_applied_strength=sum(v['applied_strength'] for v in values)/len(values))
        axes[2].plot(xs,profile.max(axis=1),label=name+' worst latent frame')
        for row in available:
            p = row['metrics'][name]['delta_h']
            if 'spatial_ratio_map' in p:
                values_map = np.asarray(p['spatial_ratio_map'])
                valid = np.asarray(p['spatial_map_valid'])
                # Max over valid video time highlights localized writes; not an object mask.
                heat = np.where(valid,values_map,np.nan)
                valid_any = valid.any(axis=0)
                heat = np.where(valid_any,np.where(valid,values_map,-np.inf).max(axis=0),np.nan)
                maps.append((name,row['step']+1,heat))
    drift = [(r['step']+1,max(r['metrics']['h15_propagated_drift']['frame_relative_rms']))
             for r in rows if 'h15_propagated_drift' in r['metrics']]
    if drift:
        axes[2].plot(*zip(*drift),ls='--',label='H15 propagated drift before writer15')
    latent = [(r['step']+1,max(r['latent_frame_rms'])) for r in rows if 'latent_frame_rms' in r]
    if latent:
        axes[3].plot(*zip(*latent),label='max latent-frame RMS')
        summary['max_latent_frame_rms'] = max(v for _,v in latent)
    for ax,label in zip(axes,('Relative delta-H','Gate and compression','Worst-frame drift','Latent RMS')):
        ax.set_ylabel(label)
        ax.set_xlabel('solver step')
        if ax.lines: ax.legend(fontsize=8)
    fig.savefig(folder/'delta_h_curves.png',dpi=140)
    plt.close(fig)
    if maps:
        fig, axes = plt.subplots(2,(len(maps)+1)//2,figsize=(14,6),squeeze=False,constrained_layout=True)
        maximum = max(float(np.nanmax(h)) for _,_,h in maps)
        for ax,(name,step,heat) in zip(axes.flat,maps):
            im = ax.imshow(heat,vmin=0,vmax=max(maximum,1e-8),cmap='magma')
            ax.set_title(f'{name}, step {step}')
            ax.set_xticks([]); ax.set_yticks([])
        for ax in list(axes.flat)[len(maps):]: ax.set_visible(False)
        fig.colorbar(im,ax=axes.ravel().tolist(),label='max over video time: delta-H RMS / H RMS')
        fig.savefig(folder/'delta_h_maps.png',dpi=140)
        plt.close(fig)
    save_json(summary,folder/'delta_h_summary.json')
    return summary


def comparison_identity(plan):
    recipe = {k:v for k,v in plan['recipe'].items() if k not in ('variant','writer_scales')}
    return dict(cases=plan['cases'], recipe=recipe, negative=plan['negative_sha256'],
                encoders=plan['encoders'], wan_checkpoint=plan['config']['paths']['wan_checkpoint'],
                wan_code=plan['config']['paths']['wan_code'])


def compare(roots, destination):
    plans = [read_json(root/'cases.json') for root in roots]
    identity = comparison_identity(plans[0])
    if any(comparison_identity(plan) != identity for plan in plans[1:]):
        raise ValueError('Cannot pair different prompts/images/geometry/seed/solver/negative/base assets')
    if len({str(root.resolve()) for root in roots}) != len(roots):
        raise ValueError('Duplicate comparison output')
    manifest = dict(condition_identity=digest(identity), outputs=[str(r.resolve()) for r in roots])
    path = destination/'comparison.json'
    if path.exists() and read_json(path) != manifest:
        raise ValueError('Comparison folder belongs to different runs; use a new destination')
    destination.mkdir(parents=True,exist_ok=True)
    save_json(manifest,path)
    review = []
    for case in plans[0]['cases']:
        for root,plan in zip(roots,plans):
            folder = root/case['key']
            meta = read_json(folder/'metadata.json')
            if meta['status'] != 'completed' or meta['case'] != case or meta['recipe'] != plan['recipe']:
                raise ValueError(f'Unfinished or stale case: {folder}')
            from inference.conditions import file_stamp
            if file_stamp(folder/'video.mp4') != meta['files']['video.mp4']:
                raise ValueError(f'Video changed after completion: {folder}')
            review.append(dict(case=case['key'], mode=case['mode'], prompt=case['prompt'],
                               output=str(root.resolve()), variant=plan['recipe'].get('variant','full'),
                               checkpoint=plan['checkpoint'], video=str(folder/'video.mp4'),
                               reviewer='', reviewed='', **{name:'' for name in QUALITY_FIELDS}, notes=''))
    review_path = destination/'paired_quality_review.csv'
    if not review_path.exists():
        with review_path.open('w',newline='') as stream:
            writer = csv.DictWriter(stream,fieldnames=list(review[0]))
            writer.writeheader(); writer.writerows(review)
    (destination/'REVIEW.md').write_text(
        '# 同条件完整视频对照\n\n逐条播放完整视频，按 case 对照不同 variant/checkpoint。'
        'CSV 中 failure 列填 0=未发现、1=失败、na=不适用；未填项不计成功。'
        'reviewer 与 reviewed=1 标明已审核。正常遮挡、出入画、液体形变不能算物体失败。'
        '静止视频即使不闪烁也不能视为动作成功；同时检查提示词动作和事件是否完成。\n\n'
        'half 在限幅后缩放两个 writer 的 ΔH；writer5_only/15_only 只关闭另一个 writer，'
        '仍计算并传递两个 P 状态。不同 variant 的完整轨迹随后会分叉；它们不是同一个 x 上的单步干预。'
        '训练 health 中的 writer_ablation 才是同一个 x、noise、sigma 的单步干预。'
        '对照脚本不把 ΔH 大小、特征相似度或 FM 自动换算成画质/物理分数。\n')
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--outputs', nargs='+',required=True)
    parser.add_argument('--comparison',help='Write a paired review manifest for two or more same-condition outputs')
    args = parser.parse_args()
    roots = [Path(p).expanduser().resolve() for p in args.outputs]
    for root in roots:
        plan = read_json(root/'cases.json')
        for case in plan['cases']:
            report_case(root/case['key'])
    if args.comparison:
        if len(roots)<2: raise ValueError('Paired comparison needs at least two outputs')
        compare(roots,output_path(args.comparison))


if __name__ == '__main__':
    main()
